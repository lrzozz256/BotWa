from . import *

__MODULE__ = "Quotly"
__HELP__ = f"""
Bantuan Untuk Quotly


• Perintah: <code>{cobadah}q</code> [text/reply to text/media]
• Penjelasan: Untuk merubah text menjadi sticker.


© {bot.me.first_name.split()[0]}
"""
