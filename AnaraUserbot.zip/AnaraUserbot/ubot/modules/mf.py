from . import *

__MODULE__ = "Memify"
__HELP__ = f"""
Bantuan Untuk Memify


• Perintah: <code>{cobadah}mmf</code> [text]
• Penjelasan: Balas Ke Sticker atau Foto akan Di ubah menjadi sticker teks meme yang di tentukan.


© {bot.me.first_name.split()[0]}
"""
