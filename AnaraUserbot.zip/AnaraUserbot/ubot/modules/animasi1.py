from . import *

__MODULE__ = "Fun"
__HELP__ = f"""
Bantuan Untuk Fun


• Perintah:  <code>{cobadah}dino</code>
• Penjelasan:  Coba sendiri.

• Perintah:  <code>{cobadah}babi</code>
• Penjelasan:  Coba sendiri.

• Perintah: <code>{cobadah}santet</code>
• Penjelasan: Coba sendiri.

• Perintah:  <code>{cobadah}gabut</code>
• Penjelasan:  Coba sendiri.

• Perintah: <code>{cobadah}sayang</code>
• Penjelasan: Coba sendiri.

• Perintah:  <code>{cobadah}hack</code>
• Penjelasan:  Coba sendiri.

• Perintah:  <code>{cobadah}hug</code>
• Penjelasan:  Coba sendiri.

• Perintah: <code>{cobadah}bomb</code>
• Penjelasan: Coba sendiri.

• Perintah:  <code>{cobadah}brain</code>
• Penjelasan:  Coba sendiri.

• Perintah: <code>{cobadah}kontol</code>
• Penjelasan: Coba sendiri.

• Perintah:  <code>{cobadah}penis</code>
• Penjelasan:  Coba sendiri.

• Perintah:  <code>{cobadah}hmm</code>
• Penjelasan:  Coba sendiri.

• Perintah: <code>{cobadah}tembak</code>
• Penjelasan: Coba sendiri.

• Perintah:  <code>{cobadah}bundir</code>
• Penjelasan:  Coba sendiri.

• Perintah: <code>{cobadah}helikopter</code>
• Penjelasan: Coba sendiri.

• Perintah:  <code>{cobadah}y</code>
• Penjelasan:  Coba sendiri.

• Perintah:  <code>{cobadah}love</code>
• Penjelasan:  Coba sendiri.

• Perintah: <code>{cobadah}awk</code>
• Penjelasan: Coba sendiri.

• Perintah:  <code>{cobadah}nah</code>
• Penjelasan:  Coba sendiri.

• Perintah: <code>{cobadah}ajg</code>
• Penjelasan: Coba sendiri.

• Perintah: <code>{cobadah}loveyou</code>
• Penjelasan: Coba sendiri.


© {bot.me.first_name.split()[0]}
"""
