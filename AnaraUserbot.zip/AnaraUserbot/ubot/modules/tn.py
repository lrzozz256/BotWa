from . import *

__MODULE__ = "Tiny"
__HELP__ = f"""
Bantuan Untuk Tiny


• Perintah: <code>{cobadah}tiny</code> [reply to sticker]
• Penjelasan: Untuk merubah sticker menjadi kecil.


© {bot.me.first_name.split()[0]}
"""
