from . import *

__MODULE__ = "Asupan"
__HELP__ = f"""
Bantuan Untuk Asupan


• Perintah:  <code>{cobadah}asupan</code>
• Penjelasan:  Untuk mengirim video asupan random.

• Perintah: <code>{cobadah}bokep</code>
• Penjelasan: Untuk mengirim video bokep random.

• Perintah:  <code>{cobadah}cewe</code>
• Penjelasan:  Untuk mengirim photo cewek random.

• Perintah: <code>{cobadah}cowo</code>
• Penjelasan: Untuk mengirim photo cowok random.

• Perintah:  <code>{cobadah}anime</code>
• Penjelasan:  Untuk mengirim photo anime random.

• Perintah: <code>{cobadah}anime2</code>
• Penjelasan: Untuk mengirim photo anime random.

• Perintah:  <code>{cobadah}pap</code>
• Penjelasan:  Untuk mengirim photo pap random.


© {bot.me.first_name.split()[0]}
"""
