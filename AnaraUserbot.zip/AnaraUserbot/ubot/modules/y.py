from . import *

__MODULE__ = "YoutubeDL"
__HELP__ = f"""
Bantuan Untuk YoutubeDL


• Perintah: <code>{cobadah}song</code> [song title]
• Penjelasan: Untuk mendownload music yang diinginkan.

• Perintah: <code>{cobadah}video</code> [video title]
• Penjelasan: Untuk mendownload video yang diinginkan.


© {bot.me.first_name.split()[0]}
"""
