from . import *

__MODULE__ = "Meme"
__HELP__ = f"""
Bantuan Untuk Meme


• Perintah: <code>{cobadah}memes</code> [text]
• Penjelasan: Untuk membuat stiker memes random.


© {bot.me.first_name.split()[0]}
"""
