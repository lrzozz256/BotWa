from . import *

__MODULE__ = "Global"
__HELP__ = f"""
Bantuan Untuk Global


• Perintah: <code>{cobadah}gban</code> [user_id/username/reply to user]
• Penjelasan: Untuk banned user dari semua group chat.

• Perintah: <code>{cobadah}ungban</code> [user_id/username/reply to user]
• Penjelasan: Untuk unbanned user dari semua group chat.


© {bot.me.first_name.split()[0]}
"""
