/*
    OZZYDEV [ Bot developer ]
    SIPUTZX [ Base and lib code ]
    AYIPSANZZZ [ bot feature idea ]
*/