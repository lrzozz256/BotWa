/**
 * Xartva Config Settings
 * BY OzzyDev and AyipSanzzz
 * Reupload? Recode? Copy code? Give the creator:)
 */

const fs = require('fs')
const { color } = require('./lib/myfunc')

global.owner = 'OzzyDev' //Input You Name
global.nomerowner = [""] //Input You Number Bot
global.botname = "𐋄𐌀𐌓𐌕ᕓ𐌀 𐌁Ꝋ𐌕" //Bot Name
global.packname = 'Created by: ' //Sticker Watermark
global.author = 'XARTVA-Bot' //Sticker Author
global.thumb = "https://l.top4top.io/p_3265i2jbk9.jpg"
global.urldb = ''; // Database URL (Don't change if you don't understand)


let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(color(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})
