const global = {
    owner: [6064818646], // ganti jadi id mu
    botToken: "7744688306:AAHWuL-fuU4wxmD1XSaocEk9mLPKvL3B2Ao",
}

module.exports = global;