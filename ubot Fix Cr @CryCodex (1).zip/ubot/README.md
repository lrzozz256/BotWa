## Userbot Ultra 
```
apt update && apt upgrade -y
```
```
git clone https://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@github.com/xhinntzy/userbot
```
```
cd userbot && screen -S userbot
```
```
apt install ffmpeg -y
```
```
bash installnode.sh
```
```
apt install python3.10-venv
```
```
python3 -m venv userbot && source userbot/bin/activate
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env && nano .env
```
```
screen -S userbot
```
```
python3 -m PyroUbot
```

