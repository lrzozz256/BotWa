const fs = require('fs')
global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6282332790754']
global.botname = 'Alwaysaqioo'
global.namaowner = 'Alwaysaqioo'
global.baileys1 = require('@whiskeysockets/baileys') 
global.sticker1 = "Alwaysaqioo"
global.sticker2 = "🌜"
global.apikey = '_'
global.capikey = '_'
global.domain = '_'
global.eggsnya = '_'
global.location = '_'
global.url1 = 'https://whatsapp.com/channel/0029Vaixj19AojYoSPwdop2U' //gausah diganti
global.url2 = 'https://whatsapp.com/channel/0029Vaixj19AojYoSPwdop2U' //
global.adana = '628XX'
global.aqris = 'https://telegra.ph/file/1701509104e6531c8a4d1.jpg'
global.aovo = '628XX'
global.agopay = '628XX'
global.mess = { 
wait: `test`
}
global.API = {
	alfa: 'https://api.zeeoneofc.my.id',
}
global.APIKeys = {
	'https://api.zeeoneofc.my.id': 'UWtTUH6RXjxQQDm',
}
global.nick = { // Custom Sesuka Lu
aaa: "⭑̤⟅̊༑ 𝑨𝒍𝒘𝒂𝒚𝒔𝒂𝒒𝒊𝒐𝒐 𝑺𝒚𝒔𝒕𝒆𝒎̊⿻‏‎‏‎‏‎‏",
bbb: "🦠̂⃟꙳͙͡༑ᐧ 🧷𝔄𝔩𝔴𝔞𝔶𝔰𝔞𝔮𝔦𝔬𝔬 المطور ᐧ ༑꙳͆⃟💚̺⃰",
ccc: "☠️⃟ ̊ ̥ ༚𐨁Qioo Not Human ̥ ̊ ༚👻⃰ꢵ⭑𝐓𝐫𝐚𝐬𝐡𝐃𝐱 𝂼઼🏳️⃰͜🏴‍☠️🏳️͜★ ꢵ ✩ ‌‌‌‌‌‌‌‌‌‌‌"
}