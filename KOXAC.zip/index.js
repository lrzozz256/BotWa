/*
        -NOTE-
   -SCRIPT KOXAC VIP
   -SCRIPT FROM DEV ALWI
   -JANGAN DIJUAL
   -TIDAK BOLEH DISEBAR
   -ANTI RIAL 5HARI DEK
  
-----╔╗╔═╦═══╦═╗╔═╦═══╦═══╗
----║║║╔╣╔═╗╠╗╚╝╔╣╔═╗║╔═╗║
---║╚╝╝║║─║║╚╗╔╝║║─║║║─╚╝
--║╔╗║║║─║║╔╝╚╗║╚═╝║║─╔╗
-║║║╚╣╚═╝╠╝╔╗╚╣╔═╗║╚═╝║
╚╝╚═╩═══╩═╝╚═╩╝─╚╩═══╝
   
*/

const _0x1c30cf = _0x4b71;
(function (_0x1fe82f, _0x3303f9) {
    const _0x25c6fb = _0x4b71, _0x148171 = _0x1fe82f();
    while (!![]) {
        try {
            const _0x1be3d0 = -parseInt(_0x25c6fb(0x157)) / (0x1 * 0x6d1 + -0x1 * -0x157 + -0x827) * (-parseInt(_0x25c6fb(0x1fc)) / (0x1d59 + 0x1a11 + -0x314 * 0x12)) + -parseInt(_0x25c6fb(0x1f8)) / (-0x6a3 * 0x4 + 0xd8a + 0x1 * 0xd05) + -parseInt(_0x25c6fb(0x14c)) / (-0x152b + 0x12 * -0xfc + -0x26e7 * -0x1) + -parseInt(_0x25c6fb(0x172)) / (0x35d + -0x2c * 0x1a + 0x1 * 0x120) * (-parseInt(_0x25c6fb(0x113)) / (0x1 * 0x1efd + 0x1136 * 0x2 + 0x1 * -0x4163)) + -parseInt(_0x25c6fb(0x10c)) / (-0x265b + -0xd * 0xcb + 0x30b1) + parseInt(_0x25c6fb(0x166)) / (-0x789 + 0x7 * 0x269 + 0x2 * -0x4a7) * (parseInt(_0x25c6fb(0x151)) / (0x1 * -0x645 + -0x764 + 0xdb2)) + parseInt(_0x25c6fb(0x142)) / (-0x1b65 + 0x1779 * 0x1 + 0x3 * 0x152);
            if (_0x1be3d0 === _0x3303f9)
                break;
            else
                _0x148171['push'](_0x148171['shift']());
        } catch (_0x561a02) {
            _0x148171['push'](_0x148171['shift']());
        }
    }
}(_0x67a8, 0x16568e + 0x47ed2 + -0x25 * 0x6389), require(_0x1c30cf(0x1fa) + _0x1c30cf(0x1c8)));
function _0x4b71(_0x223922, _0x364007) {
    const _0x5aa3cc = _0x67a8();
    return _0x4b71 = function (_0x6e1619, _0x4dc8b9) {
        _0x6e1619 = _0x6e1619 - (-0x12fa + 0x1 * -0x1d4a + 0x314b);
        let _0x476d82 = _0x5aa3cc[_0x6e1619];
        return _0x476d82;
    }, _0x4b71(_0x223922, _0x364007);
}
const func = require(_0x1c30cf(0x1fa) + _0x1c30cf(0x1e8)), readline = require(_0x1c30cf(0x16d)), usePairingCode = !![], question = _0x2af975 => {
        const _0x5cf759 = _0x1c30cf, _0x3269fa = readline[_0x5cf759(0x1af) + _0x5cf759(0x191)]({
                'input': process[_0x5cf759(0x15b)],
                'output': process[_0x5cf759(0x12d)]
            });
        return new Promise(_0x3d74b5 => {
            const _0x4352db = _0x5cf759;
            _0x3269fa[_0x4352db(0x185)](_0x2af975, _0x3d74b5);
        });
    };
async function startSesi() {
    const _0x198570 = _0x1c30cf, _0x2a3eca = {
            'upodU': function (_0x45f8be, _0x46a27a) {
                return _0x45f8be === _0x46a27a;
            },
            'rVloL': _0x198570(0x138),
            'JrkPF': function (_0x960f67, _0x302d00, _0x56f68f) {
                return _0x960f67(_0x302d00, _0x56f68f);
            },
            'VpnWo': _0x198570(0x18a),
            'ETTtZ': function (_0x568f55, _0x23b401) {
                return _0x568f55 == _0x23b401;
            },
            'gbJJm': _0x198570(0x1cb) + _0x198570(0x147) + _0x198570(0x14e) + ')',
            'ilbhC': function (_0xe5afb0, _0x3cf05b) {
                return _0xe5afb0 === _0x3cf05b;
            },
            'pxsga': function (_0x5426fb, _0x172a0b) {
                return _0x5426fb(_0x172a0b);
            },
            'oRIEP': function (_0x53c101, _0x5b95a9) {
                return _0x53c101 === _0x5b95a9;
            },
            'eXaqb': _0x198570(0x1e0),
            'xITsL': _0x198570(0x169),
            'nZUma': function (_0x4eda04, _0x105202, _0x428553) {
                return _0x4eda04(_0x105202, _0x428553);
            },
            'NaIIo': _0x198570(0x114) + _0x198570(0x10f) + _0x198570(0x18e) + _0x198570(0x12f),
            'oaPpe': function (_0x43b465, _0x40910c, _0x455cff) {
                return _0x43b465(_0x40910c, _0x455cff);
            },
            'wtDkG': _0x198570(0x114) + _0x198570(0x122) + _0x198570(0x1ce) + _0x198570(0x11d),
            'yIgcY': function (_0x183390, _0x3f0721) {
                return _0x183390 === _0x3f0721;
            },
            'tExJN': _0x198570(0x114) + _0x198570(0x19a) + _0x198570(0x1db) + _0x198570(0x168) + _0x198570(0x1b0) + _0x198570(0x1b5) + _0x198570(0x15f) + _0x198570(0x162) + _0x198570(0x13f),
            'HenDi': function (_0x8913fe, _0x595742) {
                return _0x8913fe === _0x595742;
            },
            'CzmyX': function (_0x27f8d7, _0x24b3e4) {
                return _0x27f8d7(_0x24b3e4);
            },
            'FKemS': _0x198570(0x1f3) + _0x198570(0x10d) + _0x198570(0x18d) + '.',
            'eeFzy': function (_0x3de975) {
                return _0x3de975();
            },
            'bjUoE': function (_0x1aa40f, _0xef86d9) {
                return _0x1aa40f(_0xef86d9);
            },
            'TTKvt': _0x198570(0x114) + _0x198570(0x128) + _0x198570(0x1eb) + _0x198570(0x158),
            'HoAgI': _0x198570(0x11b),
            'GtYKi': function (_0x105274, _0x6f0e31, _0x472c50) {
                return _0x105274(_0x6f0e31, _0x472c50);
            },
            'SHFuh': function (_0x378a08, _0x307469) {
                return _0x378a08 === _0x307469;
            },
            'WdvPy': _0x198570(0x1b7),
            'pnytY': function (_0x2cbd7b, _0x3e3969, _0x1fe084) {
                return _0x2cbd7b(_0x3e3969, _0x1fe084);
            },
            'Mlcbm': _0x198570(0x1c3) + _0x198570(0x197),
            'ONZvy': _0x198570(0x1f2),
            'YjNhH': function (_0x5df8f7, _0x8c0727) {
                return _0x5df8f7 === _0x8c0727;
            },
            'zUxzc': _0x198570(0x186),
            'YuMft': _0x198570(0x12e) + _0x198570(0x11a),
            'QMWFO': function (_0x4ec734, _0x222e77) {
                return _0x4ec734(_0x222e77);
            },
            'GLaGH': _0x198570(0x1cc),
            'TCvzf': _0x198570(0x201) + _0x198570(0x1da),
            'nkfou': _0x198570(0x176),
            'mLSOk': _0x198570(0x1a3),
            'Qxxci': function (_0x35dde1, _0x2b7154) {
                return _0x35dde1(_0x2b7154);
            },
            'wVCUE': function (_0x4b440c) {
                return _0x4b440c();
            },
            'kJrbF': _0x198570(0x1bf) + _0x198570(0x178) + _0x198570(0x117) + _0x198570(0x1aa) + _0x198570(0x17c) + _0x198570(0x17a) + _0x198570(0x112) + _0x198570(0x1be) + _0x198570(0x19c) + _0x198570(0x1de) + _0x198570(0x188) + _0x198570(0x17b) + _0x198570(0x124) + _0x198570(0x127) + _0x198570(0x15a) + _0x198570(0x1bb) + _0x198570(0x183) + _0x198570(0x19d) + _0x198570(0x179) + _0x198570(0x160) + _0x198570(0x18b) + _0x198570(0x12c) + _0x198570(0x1d8) + _0x198570(0x159) + _0x198570(0x1e2) + _0x198570(0x16c) + _0x198570(0x110) + _0x198570(0x1d3) + _0x198570(0x108) + _0x198570(0x184) + _0x198570(0x1f4) + _0x198570(0x1d2) + _0x198570(0x1f6) + _0x198570(0x10e) + _0x198570(0x140) + _0x198570(0x161),
            'qZUEH': function (_0x47a37d, _0x4bfcae) {
                return _0x47a37d(_0x4bfcae);
            },
            'IkSHM': _0x198570(0x1fb),
            'IzGSD': _0x198570(0x1b9),
            'JVKul': _0x198570(0x198),
            'HyZES': _0x198570(0x1d7),
            'AJoFa': function (_0x24df6c, _0x363b0d) {
                return _0x24df6c(_0x363b0d);
            },
            'GCpNA': _0x198570(0x13a) + _0x198570(0x193) + _0x198570(0x164) + _0x198570(0x1b8) + _0x198570(0x1d1) + _0x198570(0x16b) + _0x198570(0x118) + _0x198570(0x152) + _0x198570(0x1c2) + _0x198570(0x15d) + _0x198570(0x1f9) + _0x198570(0x13b) + _0x198570(0x1f7) + _0x198570(0x200) + _0x198570(0x107) + _0x198570(0x1e4) + _0x198570(0x17f) + _0x198570(0x13c) + _0x198570(0x1a0) + _0x198570(0x11f) + _0x198570(0x1b3),
            'aoTpV': _0x198570(0x1df) + _0x198570(0x13d),
            'ICjIt': _0x198570(0x192) + _0x198570(0x1d5),
            'JbjAy': _0x198570(0x129) + _0x198570(0x12b),
            'uFGRr': _0x198570(0x1a4) + 'te'
        }, _0x19cfdf = _0x2a3eca[_0x198570(0x17d)](makeInMemoryStore, {
            'logger': _0x2a3eca[_0x198570(0x187)](pino)[_0x198570(0x1c7)]({
                'level': _0x2a3eca[_0x198570(0x134)],
                'stream': _0x2a3eca[_0x198570(0x1d4)]
            })
        }), {
            state: _0x11260d,
            saveCreds: _0x2a01a8
        } = await _0x2a3eca[_0x198570(0x10a)](useMultiFileAuthState, _0x198570(0x1ab)), {
            version: _0x4c22bb,
            isLatest: _0x3dbf79
        } = await _0x2a3eca[_0x198570(0x1e3)](fetchLatestBaileysVersion);
    console[_0x198570(0x14f)](chalk[_0x198570(0x15e)][_0x198570(0x146)](_0x2a3eca[_0x198570(0x1f1)]));
    const _0x218a6b = {
            'version': _0x4c22bb,
            'keepAliveIntervalMs': 0x7530,
            'printQRInTerminal': !usePairingCode,
            'logger': _0x2a3eca[_0x198570(0x16e)](pino, { 'level': _0x2a3eca[_0x198570(0x126)] }),
            'auth': _0x11260d,
            'browser': [
                _0x2a3eca[_0x198570(0x17e)],
                _0x2a3eca[_0x198570(0x10b)],
                _0x2a3eca[_0x198570(0x153)]
            ]
        }, _0x21c24f = func[_0x198570(0x1c6) + 'et'](_0x218a6b);
    if (usePairingCode && !_0x21c24f[_0x198570(0x14a)][_0x198570(0x173)][_0x198570(0x133)]) {
        const _0x3123dd = await _0x2a3eca[_0x198570(0x18f)](question, chalk[_0x198570(0x156)](_0x2a3eca[_0x198570(0x1bc)])), _0x195872 = await _0x21c24f[_0x198570(0x1a6) + _0x198570(0x125)](_0x3123dd[_0x198570(0x1a5)]());
        console[_0x198570(0x14f)](chalk[_0x198570(0x156)](_0x198570(0x202) + _0x198570(0x1c0) + _0x195872 + '\x20'));
    }
    return _0x19cfdf[_0x198570(0x1e5)](_0x21c24f['ev']), _0x21c24f['ev']['on'](_0x2a3eca[_0x198570(0x1ed)], async _0x5d16ea => {
        const _0x5b203a = _0x198570, {
                connection: _0x31d111,
                lastDisconnect: _0x536628
            } = _0x5d16ea;
        if (_0x2a3eca[_0x5b203a(0x1ef)](_0x31d111, _0x2a3eca[_0x5b203a(0x175)])) {
            const _0x3cd6a7 = new Boom(_0x536628?.[_0x5b203a(0x199)])?.[_0x5b203a(0x18c)][_0x5b203a(0x13e)];
            console[_0x5b203a(0x14f)](_0x2a3eca[_0x5b203a(0x141)](color, _0x536628[_0x5b203a(0x199)], _0x2a3eca[_0x5b203a(0x135)]));
            if (_0x2a3eca[_0x5b203a(0x1c4)](_0x536628[_0x5b203a(0x199)], _0x2a3eca[_0x5b203a(0x180)]))
                process[_0x5b203a(0x150)]();
            else {
                if (_0x2a3eca[_0x5b203a(0x148)](_0x3cd6a7, DisconnectReason[_0x5b203a(0x14b)]))
                    console[_0x5b203a(0x14f)](_0x2a3eca[_0x5b203a(0x1c1)](color, _0x5b203a(0x11c) + _0x5b203a(0x181) + _0x5b203a(0x1ac) + _0x5b203a(0x203) + _0x5b203a(0x1f5) + _0x5b203a(0x1d0))), process[_0x5b203a(0x150)]();
                else {
                    if (_0x2a3eca[_0x5b203a(0x165)](_0x3cd6a7, DisconnectReason[_0x5b203a(0x1df) + _0x5b203a(0x1f0)]))
                        console[_0x5b203a(0x14f)](_0x2a3eca[_0x5b203a(0x141)](color, _0x2a3eca[_0x5b203a(0x1e9)], _0x2a3eca[_0x5b203a(0x16f)]), _0x2a3eca[_0x5b203a(0x1dd)](color, _0x2a3eca[_0x5b203a(0x119)], _0x2a3eca[_0x5b203a(0x135)])), process[_0x5b203a(0x150)]();
                    else {
                        if (_0x2a3eca[_0x5b203a(0x148)](_0x3cd6a7, DisconnectReason[_0x5b203a(0x1df) + _0x5b203a(0x1a7)]))
                            console[_0x5b203a(0x14f)](_0x2a3eca[_0x5b203a(0x1a1)](color, _0x2a3eca[_0x5b203a(0x1e9)], _0x2a3eca[_0x5b203a(0x16f)]), _0x2a3eca[_0x5b203a(0x141)](color, _0x2a3eca[_0x5b203a(0x177)], _0x2a3eca[_0x5b203a(0x135)])), process[_0x5b203a(0x150)]();
                        else {
                            if (_0x2a3eca[_0x5b203a(0x1b1)](_0x3cd6a7, DisconnectReason[_0x5b203a(0x1df) + _0x5b203a(0x1c5)]))
                                console[_0x5b203a(0x14f)](_0x2a3eca[_0x5b203a(0x1c1)](color, _0x2a3eca[_0x5b203a(0x136)])), _0x21c24f[_0x5b203a(0x19e)]();
                            else {
                                if (_0x2a3eca[_0x5b203a(0x1b1)](_0x3cd6a7, DisconnectReason[_0x5b203a(0x174)]))
                                    console[_0x5b203a(0x14f)](_0x2a3eca[_0x5b203a(0x1c1)](color, _0x5b203a(0x116) + _0x5b203a(0x12a) + _0x5b203a(0x163) + _0x5b203a(0x1ea) + _0x5b203a(0x196))), _0x21c24f[_0x5b203a(0x19e)]();
                                else {
                                    if (_0x2a3eca[_0x5b203a(0x132)](_0x3cd6a7, DisconnectReason[_0x5b203a(0x1e6) + _0x5b203a(0x144)]))
                                        console[_0x5b203a(0x14f)](_0x2a3eca[_0x5b203a(0x1a8)](color, _0x2a3eca[_0x5b203a(0x1a2)])), await _0x2a3eca[_0x5b203a(0x187)](startSesi);
                                    else
                                        _0x2a3eca[_0x5b203a(0x165)](_0x3cd6a7, DisconnectReason[_0x5b203a(0x1ec)]) && (console[_0x5b203a(0x14f)](_0x2a3eca[_0x5b203a(0x17d)](color, _0x2a3eca[_0x5b203a(0x143)])), _0x2a3eca[_0x5b203a(0x187)](startSesi));
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (_0x2a3eca[_0x5b203a(0x148)](_0x31d111, _0x2a3eca[_0x5b203a(0x194)]))
                _0x2a3eca[_0x5b203a(0x111)](start, '1', _0x5b203a(0x120) + _0x5b203a(0x130));
            else
                _0x2a3eca[_0x5b203a(0x1d6)](_0x31d111, _0x2a3eca[_0x5b203a(0x109)]) && (_0x2a3eca[_0x5b203a(0x145)](success, '1', _0x5b203a(0x1e7)), _0x21c24f[_0x5b203a(0x19b) + 'e'](_0x5b203a(0x1b6) + _0x5b203a(0x1e1) + _0x5b203a(0x11e), { 'text': _0x5b203a(0x195) + _0x5b203a(0x1fd) + _0x5b203a(0x139) + _0x5b203a(0x1d9) }), autoJoin && _0x21c24f[_0x5b203a(0x190) + _0x5b203a(0x131)](codeInvite));
        }
    }), _0x21c24f['ev']['on'](_0x2a3eca[_0x198570(0x1ba)], async _0x43fa5e => {
        const _0x172252 = _0x198570;
        try {
            const _0x2838be = _0x2a3eca[_0x172252(0x1ae)][_0x172252(0x1cf)]('|');
            let _0x211ec9 = 0xb26 + 0x6c5 * -0x4 + -0x2 * -0x7f7;
            while (!![]) {
                switch (_0x2838be[_0x211ec9++]) {
                case '0':
                    m = _0x43fa5e[_0x172252(0x1b4)][0x3c * 0x79 + -0x21b1 + -0x5b * -0xf];
                    continue;
                case '1':
                    if (m[_0x172252(0x137)]['id'][_0x172252(0x1ff)](_0x2a3eca[_0x172252(0x1ca)]) && _0x2a3eca[_0x172252(0x1b2)](m[_0x172252(0x137)]['id'][_0x172252(0x1dc)], -0x175b + 0x1b05 + -0x39a))
                        return;
                    continue;
                case '2':
                    if (!_0x21c24f[_0x172252(0x121)] && !m[_0x172252(0x137)][_0x172252(0x1ad)] && _0x2a3eca[_0x172252(0x165)](_0x43fa5e[_0x172252(0x15c)], _0x2a3eca[_0x172252(0x1c9)]))
                        return;
                    continue;
                case '3':
                    if (!m[_0x172252(0x154)])
                        return;
                    continue;
                case '4':
                    if (m[_0x172252(0x137)] && _0x2a3eca[_0x172252(0x132)](m[_0x172252(0x137)][_0x172252(0x189)], _0x2a3eca[_0x172252(0x1fe)]))
                        return _0x21c24f[_0x172252(0x1a9) + 'es']([m[_0x172252(0x137)]]);
                    continue;
                case '5':
                    m = func[_0x172252(0x16a)](_0x21c24f, m, _0x19cfdf);
                    continue;
                case '6':
                    _0x2a3eca[_0x172252(0x14d)](require, _0x2a3eca[_0x172252(0x170)])(_0x21c24f, m, _0x19cfdf);
                    continue;
                case '7':
                    m[_0x172252(0x154)] = _0x2a3eca[_0x172252(0x1d6)](Object[_0x172252(0x1ee)](m[_0x172252(0x154)])[-0xc68 + 0x6 * -0x1a8 + 0x104 * 0x16], _0x2a3eca[_0x172252(0x149)]) ? m[_0x172252(0x154)][_0x172252(0x201) + _0x172252(0x1da)][_0x172252(0x154)] : m[_0x172252(0x154)];
                    continue;
                }
                break;
            }
        } catch (_0x5b7b8c) {
            console[_0x172252(0x14f)](_0x5b7b8c);
        }
    }), _0x21c24f['ev']['on'](_0x2a3eca[_0x198570(0x155)], _0x2947ee => {
        const _0x96f63f = _0x198570;
        for (let _0x2c5808 of _0x2947ee) {
            let _0x4ea6c3 = _0x21c24f[_0x96f63f(0x182)](_0x2c5808['id']);
            if (_0x19cfdf && _0x19cfdf[_0x96f63f(0x167)])
                _0x19cfdf[_0x96f63f(0x167)][_0x4ea6c3] = {
                    'id': _0x4ea6c3,
                    'name': _0x2c5808[_0x96f63f(0x186)]
                };
        }
    }), _0x21c24f[_0x198570(0x121)] = !![], _0x21c24f['ev']['on'](_0x2a3eca[_0x198570(0x1bd)], _0x2a01a8), _0x21c24f;
}
function _0x67a8() {
    const _0x4e04cf = [
        'e\x20Current\x20',
        '║░░██║╚███',
        '𝑹𝑨𝑺𝑯',
        'Session\x20Fi',
        'lease\x20Scan',
        'KODE\x20SESUA',
        'oRIEP',
        '56iCPPyh',
        'contacts',
        'ew\x20Session',
        'white',
        'smsg',
        '\x20MASUKIN\x20N',
        '𝑨𝑪\x20𝑽𝑬𝑹𝑺𝑰𝑶𝑵',
        'readline',
        'qZUEH',
        'xITsL',
        'GLaGH',
        'oepGz',
        '3715345VkLYyN',
        'creds',
        'loggedOut',
        'rVloL',
        'silent',
        'wtDkG',
        '████╗░██╗░',
        '██╔╝╚██╗██',
        '█╔══██╗╚██',
        '███║██║░░╚',
        '\x0a██║░██╔╝█',
        'bjUoE',
        'IzGSD',
        'F\x20KOXAC,\x20I',
        'gbJJm',
        'n\x20File,\x20Pl',
        'decodeJid',
        '██╗\x0a██║░╚█',
        '𝑯\x0a𝑻𝑬𝑳𝑬𝑮𝑹𝑨𝑴',
        'question',
        'notify',
        'eeFzy',
        '███╔╝░████',
        'remoteJid',
        'deeppink',
        '██╔╝\x0a╚═╝░░',
        'output',
        'starting..',
        'econnectin',
        'AJoFa',
        'groupAccep',
        'rface',
        'messages.u',
        ':\x20MASUKAN\x20',
        'HoAgI',
        '`ƬΣЯƧΛMBЦП',
        '\x20Run.',
        '1|5|6',
        'Chrome',
        'error',
        '\x20Replaced,',
        'sendMessag',
        '╗\x0a█████═╝░',
        '█╗╚█████╔╝',
        'logout',
        'Caught\x20exc',
        'K,\x20DEK\x0a\x0aNO',
        'oaPpe',
        'FKemS',
        'store',
        'creds.upda',
        'trim',
        'requestPai',
        'Lost',
        'CzmyX',
        'readMessag',
        '╗░░█████╗░',
        './session',
        'ease\x20Delet',
        'fromMe',
        'Mlcbm',
        'createInte',
        '\x20Opened,\x20P',
        'yIgcY',
        'YjNhH',
        '\x20:\x20',
        'messages',
        'lease\x20Clos',
        '6285260483',
        'open',
        'I\x20NEGARA\x20A',
        'Ubuntu',
        'ICjIt',
        '══██║██║░░',
        'GCpNA',
        'uFGRr',
        '██╗██╔══██',
        '██╗░░██╗░█',
        'ng\x20Code\x20:\x20',
        'pxsga',
        'EK\x0aSUB\x20ENG',
        '0|3|7|4|2|',
        'ETTtZ',
        'Replaced',
        'makeWASock',
        'child',
        '/global',
        'zUxzc',
        'ONZvy',
        'Error:\x20Str',
        './nugraha',
        'ception',
        'ing\x20to\x20rec',
        'split',
        'gain',
        'NDA\x20JANGAN',
        '𝑨𝑺𝑯\x0a𝑺𝑼𝑩𝑺𝑪𝑹',
        '𝑬𝑹\x20𝑺𝑪𝑹𝑰𝑷𝑻\x20',
        'mLSOk',
        'psert',
        'SHFuh',
        '20.0.04',
        '░╚═╝░░╚═╝╚',
        'sful',
        'essage',
        '\x20Another\x20N',
        'length',
        'nZUma',
        '██║░░██║░╚',
        'connection',
        '[SYSTEM]',
        '560@s.what',
        '═══╝░\x0a\x0a𝑲𝑶𝑿',
        'wVCUE',
        'THE\x20NAME\x20O',
        'bind',
        'restartReq',
        'Tersambung',
        '/place',
        'eXaqb',
        '\x20Again\x20And',
        '\x20Reconnect',
        'timedOut',
        'aoTpV',
        'keys',
        'upodU',
        'Closed',
        'kJrbF',
        'BAE5',
        'Restart\x20Re',
        '\x20:\x20@𝑨𝑳𝑾𝑰𝑪𝑹',
        'and\x20Scan\x20A',
        '𝑰𝑩𝑬\x20𝑫𝑶𝑵𝑮\x20𝒀',
        'G\x20TO\x20YOUR\x20',
        '812244usOhpP',
        'ER\x20THE\x20COD',
        './database',
        'fatal',
        '6bwZNGb',
        'G`\x0a\x20Bot\x20Ko',
        'YuMft',
        'startsWith',
        'COUNTRY,\x20D',
        'ephemeralM',
        'Your\x20Pairi',
        'e\x20Session\x20',
        'ONT\x20ENTER\x20',
        ':\x20𝑨𝑳𝑾𝑰𝑪𝑹𝑨𝑺',
        'WdvPy',
        'Qxxci',
        'JVKul',
        '11105948PFvAcf',
        'quired,\x20Re',
        '𝑶𝑼𝑻𝑼𝑩𝑬\x20𝑺𝑨𝒀',
        '\x20closed,\x20r',
        '\x20𝟗𝟗𝟗\x0a\x0a\x20𝑴𝑨𝑲',
        'GtYKi',
        '╗██╔╝██╔══',
        '6RCIEPi',
        'Connection',
        'uncaughtEx',
        'Device\x20Log',
        '░██╗░█████',
        'AMA\x20KOXAC\x20',
        'NaIIo',
        'adcast',
        'connecting',
        'Bad\x20Sessio',
        'onnect',
        'sapp.net',
        'MOR/NUMBER',
        'Connecting',
        'public',
        '\x20lost,\x20try',
        'eption:\x20',
        '═╝\x0a██╔═██╗',
        'ringCode',
        'IkSHM',
        '░██║░░██║░',
        '\x20TimedOut,',
        'contacts.u',
        'ged\x20Out,\x20P',
        'pdate',
        '╚═╝░╚════╝',
        'stdout',
        'status@bro',
        'g...',
        '...',
        'tInvite',
        'HenDi',
        'registered',
        'nkfou',
        'VpnWo',
        'tExJN',
        'key',
        'close',
        'xac\x20Succes',
        '\x0aSUB\x20INDO\x20',
        'E\x20ACCORDIN',
        'T\x20DONT\x20WOR',
        '.update',
        'statusCode',
        'rst',
        '𝑨\x20:\x20@𝑨𝑳𝑾𝑰𝑪',
        'JrkPF',
        '178100HYjipx',
        'TTKvt',
        'uired',
        'pnytY',
        'bold',
        'eam\x20Errore',
        'ilbhC',
        'TCvzf',
        'authState',
        'badSession',
        '38160CGeCrH',
        'QMWFO',
        'd\x20(unknown',
        'log',
        'exit',
        '1005633BUxOic',
        'GAK\x20BISA\x20D',
        'HyZES',
        'message',
        'JbjAy',
        'green',
        '379859IzYcRy',
        'ing...',
        '═╝░░╚═╝░╚═',
        '██╔██╗░██╔',
        'stdin',
        'type',
        'LISH\x20:\x20ENT',
        'red'
    ];
    _0x67a8 = function () {
        return _0x4e04cf;
    };
    return _0x67a8();
}
startSesi(), process['on'](_0x1c30cf(0x115) + _0x1c30cf(0x1cd), function (_0x505cf2) {
    const _0x330142 = _0x1c30cf, _0x4b9c78 = { 'oepGz': _0x330142(0x19f) + _0x330142(0x123) };
    console[_0x330142(0x14f)](_0x4b9c78[_0x330142(0x171)], _0x505cf2);
});