// Xangjing Settings Code
// By OzzyDev
// Jangan ganti author!!!

global.prefa = ['','!','.',',','🐤','🗿','🩲'] //JANGAN GANTI
global.owner = ['6281927977856'] //OWNER
global.botname = 'Xangjing V1.0.0' //BOT NAME
global.baileys1 = require('@whiskeysockets/baileys') //NOT CHANGE
global.creator = "OzzyDev" //NOT CHANGE
global.packname = "By: " //OPSIONAL
global.author = "OzzyDev" //OPSIONAL
global.idCH = "120363321780343299@newsletter" // OPSIONAL