const fs = require('fs')
const { color } = require('./lib/myfunc')

global.owner = '6281927977856'
global.nomerowner = ["6281927977856"]
global.packname = 'Created by: '
global.author = 'XARTVA-Bot'
global.urldb = ''; // kosongin aja



let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(color(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})
