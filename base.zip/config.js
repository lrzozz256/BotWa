/**

 * Base By Siputzx
 * Created On 22/2/2024
 * Contact Me on wa.me/6288292024190
 * Web AI rusak, ganti aja yg baru
 
 • Fixxed by Dgf ziyo {
 - Database
 - Pairing code
 - message.js
 - index.js
 - lib/lowdb
 }
 
• Moumantai.. Terrier Asistant using this base !

• Vee... Headshot, Veemon Bot using this base !

**/

const fs = require('fs')
const { color } = require('./lib/myfunc')

global.owner = '6285658939117'
global.nomerowner = ["6285658939117"]
global.packname = 'Di Buat Oleh'
global.author = 'Siputzx -MD'
global.urldb = ''; // kosongin aja



let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(color(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})
